# -*- coding: utf-8 -*-
# Protected by Manga Translation Studio IP Shield (https://comic.io.vn)
import base64 as _b64, hashlib as _hl, zlib as _zl
_K = _hl.sha256('MangaStudioProtected::sources.py'.encode('utf-8')).digest()
_P = (
    "9G&0FNN?~t3xuZwZb~p3Hu32K&lNuXbtbzVrwTy}DpOAyLUT%qt^bY6n<|DX*D2%>EB9HKJS)P)*_!$vM8{&33qtaj@<q67lQ7)O"
    "Hot^9%V)~g=cWs$Z=rN4idu^Q&!U9RD=B&QQmojWGz)dbu4D~^o^g-?3ekoZiyij-EM(Gdvtmv3M)a_xJO;S7L#(6n4<_ECl+f1^"
    "7j!6gec3U6)il4A0N4eSk~tn3tZiRoZAb(xtsq>=v4-`rOr@RNZ>$(L4$!r`aEzZz0mEa7*%>4)vS&w)pth(Ggtr5cUtt>}Y}2+p"
    "C44XsS~pnANWbp!%b0C5Oa9PYAhC0Wy%Ebe<(m!ECOjqzn*Lg>MA~OQg_uCVUppNS(9=|iV&Fq6GC%J@o9I1u+M*gN{g7Dli-hqE"
    "5-A;z-uW@`uSDdU1Ol??YPT<m;t?Ss`S9>(w2?spA+XTvF@_-pug}-I5N|5H8N>}rWz1NhN(eJev1>ilC^f@wBdiu3RwrILcpYuF"
    "OG~fhaLNz0yRHcB*{Ex)B;1_MxFdNKdTVb}jd-K$g$7waqMtf&kPFK|5}i7tjgbRm)nPE^M-HIywRJhmg)n<0-4;lB_aD~P;+%;r"
    "`U8pd5FHOJPzGb_N57WaR>N-c*@7o^U0)&Sr{!Jqrx0n5pw9%u$w+)bmCi4h;_#yyw=L&8*KIVTM!n*a>-C7RMB54Ox5<VCA!Qyw"
    "2TqRm%LYr8t(n;Qbc)SCs<P(y&f=tGi{}M{(dP+3%g2`iw(uKe0eLzkp<~ySrpJT%W-8~u9THx`v5`E^E=sM6?6UOZ%Ir~D%-N^I"
    "Eo7u-RS+C7UE<X`Xvg)Gig`Qz`CkxSJ|#<ApZ9{OKCPo}){RjBU|~L2-$Z6`{Mr)WWMao>>MZuyFLuV*T3pt?)AaZJUAi5A%bG;a"
    "Ji+jDM*-yMFo^nAr#_2aqxah9?*1y^p^F{XJaa2P>gX29o?BC(-rMS5M$i1V_j`BkU~>GTdmNv6a!1)zGfYF@uL@F6|LGl3LxVws"
    "*RzYKb-9O4TbmX4`FW{V6i%RGFkBD7DRH{w#XU2AS-Vm;WFa*_$S^M8(uT#K9&S0R$Ww$n-`X@=F7WkUZ@W3pq~QY(6UB1Pz^6*?"
    "#(z>)yiG225i5TUx^9qIxoV&;^!+g-{ydn72WVI><;}1Crj=P$=qgGM`C2U1LR}Gnj0n0{HnzK9(PFznMiw!pl7H^JwmGu-9#iNg"
    "N$(T{=s<8vof-`Oiw~RKdIQ5nyPlNjIj-B+A*GB!^Udu-f&&9kFY&(J-b!)m9KSG7{wxfMaU?)s<qXrZp!=uS3AL`BxF;vRkJlW7"
    "XNY`hzS1wd<KW?-h5AYy)O8-Sj(0~EnmkbjG~ed#+gMKPbK1;6NOna{SIWVX?)12+BLbQoFfHrCP}V|Dx_}<xt8hu*l*7a~hcqKM"
    "CO3Z^|ACvl>GB2hHsSp`sFG>*Fp;b4gaf0&SAYVWP85>LTk=}{j|x3PX_B*<i8-yT?7hzK^<mUq?r1|t&Px#D{Kz<dicvDQO7)IP"
    "CMW*pboVp`oCtB-@$Zgn(B<S0QDuhC62Aq}@X@@=@<nbgGXRmmm?jJHxR_I!DTtgtqwsZL<!j~ph1=9HV7JgD#&Ne6tc(>iQ5FS#"
    "f6&&1v3vUgNqN!*gVPxMzvG+R_}blu`P~iqp#u#3tmnMGgAjB?Vo#X1GrYcuu!jO@Jx7Gw3s373;1KMiHH_)(sbK^>*Bk%TFn+Po"
    "jOtlTtgKWD6P3O8p5;DL=se>#Yf5q<6?;DgmN(iu9_wGC2=A*hQrikm$>>~0%d}BFP$2>2Qe@j^bnDdobsI!P>U0ZzQf~E{edu^t"
    "la&tJRwvVX=9i^8#p}_5gX~36P#d|uxSQ4e2-|(fz7#S7NE+Zf`On_9!>a}s->RymFHNj)R*5dKtnugdRYMe~gt#vr=fJU`CMv_n"
    "&mq)ve}k&-D;U5i@n$uMS6u>PVk1H)`~QC;+RaeFMe_8X&xe$Sg7|6finw}C_^%aoo_QXm)^9>w!WE2I2^GVLfl>|FL;(E-sJ9XM"
    ")klIe_PdC^eNX`FtLd9_aSu()m`B_b6EZmu)Ozf8AjRLvGt5^rsfx?f5+mri0qcjAu1(n;z`hZ6NTfu6ShvLV`~Z_+ifZ;BJ-#FC"
    "$A(K4-krDa&u)gYcPzCo(>fh~v|F2mk6n$G(k-GvTbhbY{tmyBdbV6^eRZ))bJOD6qk*7%UqsOP4|PI0^=XzmZx5(BtD1Pf_~RT+"
    ")Ozn&f@Lg>6$5T@p)jF3`G*b>Hvt5|Y&bE`Qd7lj$R0{7fAH<gk0bCk>+fta>(5gfSLvsdnVy+lAR|R!V{{kWDZpLEAyPOX<FP8}"
    "07`b#$nZb`X85N>(u}WG;<w>K#(#XEI*jVD6a@rp2iUNr?h4&e)bHa#i+SHO^-eh>rP|;YpeKI=BOh1|vzM{5AfC-xY(t5-w06U6"
    "XN~D7^Qj=gSguC{={r5Cl2r=RJ8_v?`vA&gA$))-$=OuK*422Jx`t{JO57Yl^hkSWYnO-m^K^&{wi%w9e+5swUimT*G+g}Q-x8!|"
    "52g^g%|SD6+6;|`$B8L;A<--!v-NiAoMdN_cqzs0598zzkc1=>&C{Ei(RXy#+=b`8?QDDl7dS;G0owf<$dpW?7~A5N#k_0z$n%5`"
    "E3GF&z}uVQCq!odAwXU&?!5cxv;8cWYo`T~e7G^-ovaig7v001Jup$TrEj<t?BUYU%$Ml{b43D?23cU9XTsF5C!<AVZ3a1y9C8Mt"
    "yefXutfLl9WN`hukP%=~v57n2LRR4i{4>9a$#Pj43%VzDd@$1vn(L+om_8KgcaEUb!fd&)p%^tOi32xC1S+(<MMk%Gr^XS86e&%<"
    "9{b1UrHOW*#!s!Zjq{l!`ZaLT<&_?s&WTn!GL@Oz_m-`-Bdm4N(Z_nhs@p1Ogg*z1UXDX*>4|>S2S4~tZ}@HWJ<6p%?s}8c8l&ih"
    "ztO|zb&#`;AqInG@?<FU<nV<K5rRVMG>tGHIwMFJu@T`qGRkSb@$sdh>orlND(kH~vUPPJHb>6$@3FB^Q?A#bdJa0199zuHus!Wf"
    "xRO4_4Ajh}yjbR#pd1*~SwX%L1hEr_%kiQ0*9UuceehSMO#WW5*ok5-$tpO;KbrxaJv#<uc6uv5=U8gkqJ)#Td=6BGi)TW(Viwkg"
    "kfwbaj*s1o<(6avNtMdBr)=u-vU>z9r!1;ZL@TYbA5A*zQ=B>7t+yWa2~GQ!(mx-NG5_NuGprT"
)
_R = _b64.b85decode(_P.encode('ascii'))
_C = _zl.decompress(bytes(b ^ _K[i % len(_K)] for i, b in enumerate(_R)))
del _b64, _hl, _zl, _K, _P, _R
exec(compile(_C, __file__, 'exec'), globals())
