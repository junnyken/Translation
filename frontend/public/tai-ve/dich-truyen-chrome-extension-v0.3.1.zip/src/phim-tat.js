;(() => {
if (window.__translation_phim_tat_da_cai__) return
window.__translation_phim_tat_da_cai__ = true
window.addEventListener('keydown', (e) => {
if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || e.repeat) return
const tag = (e.target?.tagName || '').toLowerCase()
if (tag === 'input' || tag === 'textarea' || e.target?.isContentEditable) return
if (window.__translation_doc_truyen__?.daCaiPhimAlt) return
const k = (e.key || '').toLowerCase()
const bangLenh = {
q: 'dich-trang-nay',
a: 'dich-ca-chapter',
w: 'tu-dich-khi-cuon',
s: 'khoanh-vung-dich',
}
const lenh = bangLenh[k]
if (!lenh) return
e.preventDefault()
try {
chrome.runtime?.sendMessage?.({ viec: 'phim-tat', lenh })?.catch?.(() => {})
} catch {
}
})
})()
