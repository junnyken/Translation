import{defineConfig as e}from"vitest/config";export default e({test:{environment:"jsdom",include:["tests/**/*.test.js"]}});
