# -*- coding: utf-8 -*-
# Protected by Manga Translation Studio IP Shield (https://comic.io.vn)
import base64 as _b64, hashlib as _hl, zlib as _zl
_K = _hl.sha256('MangaStudioProtected::sources.py'.encode('utf-8')).digest()
_P = (
    "9G&0FNN@Ky3xvM|E<2krHlm5H?#A=9I2KjHR_=yJzJpWN51QY@eqoo&n<^$}1R3NIEBASqJgcN!s@D(UcSBMm0)nKuG{$SJl{b9e"
    "uIl6-=@LbMtyi@hl8!yr5p?u=mjtb%vUuin`WZ8(583C_oh_+M{2q;;c4yya-y?@e2%agzdm&|>L(Rb9I-D!pp$9co%h>|*t7?g{"
    "&S7hemfevC_Nr?52P)eALH7VJb)$PJJObtq9_U^OYWarB!Ik;f$&y?J4HrorKAE%39;5qEcP(U*6o2yPLtJf*-M&-h_5_WK2Od@9"
    "j25mXbjwy6Z6B9*!NdkX0EJ#0+9;neECh`&CM*{GwI4Ptz=vie`Z5v}%8*4*l$KUNOl3D8b7Z{5xBQtM-v~+|sDU=l(@$3CdaTuM"
    "ySZ8`@Vk*C;CsX9mD3V5BC66tqwkL>@i_V|hp1MEla<m7!R9d};AA^DS*7;JKe+mUYk<mrhYe>!r=&Qc2bGs^sXw4Q3#oow{W0Se"
    "y7M+ASKD^`lG2?90(Z^sVuTdb!Nm<!Y%uz6xV0FRSDxmgmZt%|qyo#?XE<lr<A*sEQ>BO?%4sXtTJ0{$XjPbqxb#Il?FjGFOUAGf"
    "I(Sd_i%aJSMuRfGIu$|W7dioAe;EOne38N8)(Vfb7hb?z_j|?%f-%kj*KE{skJ8M>ZaB<zoc02$?M;MHj$|Q7W)ML&$Z9WJZN?n;"
    "nuK%^DP?)be?x-r&Lfv;mGW0$V6MuTT?dn=X6qlnih992w1>xJ?r$>6RyqWieCaebu@IPkxLWNJg}fCfRUZ86{O+r|JaPbR9bewm"
    "2ptWU0&kIe2hwtP5EGCdK4&XC)=wUVWRx)`fB_rPYgrEc3<oht&OBZyKmg@O^P_6HE`av#8UZvH-0i-y3>?CWHw2>oiF|gd!Ar;r"
    "V640on21kAFEfKRYvx7b6|T4t?jcoAxj%V%-X6z7>vf+h2AJXw8-@7jaq{3X;QsGgop)(x7LD}Y8aOavZx|2D`_*>m(#G+Kn_E&="
    "`w;;MxOVpH@DFaN!o>q-#UAy#b5Y7bt*O|erPC!TkZi`OTNszx>G>eeoBQ1!svZJKELDc`>EwPw_^g~vj<6Z;!N1Pyc|zzZDU+Ie"
    "JkbI~zeJe+STDLu!s7M+yLwt1ZNMOX86}J8fkh7$RLRU-3bkQjG1*rf1kYge#s>FeU%9%?CEP@eDuX`?h~+?a&K=_jayiZ+gzkCo"
    "W97!K2cf=m2>&4PH-C;Q2xicIxZn|i+Fv5yM-?0X)ikvWX7hM`74{(e4Vc(>yP#u5I=h6#X8_lVX&#b+@dW`f8gmM&s2|sUn)PU^"
    "&ToTQ{e`ckt*L(e_b2KKlkK__1p(cVq4m;&G53l0XY6dWp`}_p#QD$~9$n5uIxDwv)iRxor{7q80O^`N9XpyT?H`-Ijs=DoLrDGg"
    "DzaXFr8AyXF9RnIUI(w|y~KUK^~r2gy?a{-1U#e*ze{%CCTXM~aZ&~oS&YSCNn*}YazuUerlGJ^A-OaX!A5*U&&18Zmzbi8&ByP^"
    "ph>RL6glrj0V_sX_JQNp@<HKyBdXkctmvjcIW1#C{Ju1Owf`hKWDCc?HYCBT9-(#Y7vu+Nb>*0QgyPLP;xO^EzI$}6)6O12j*&S^"
    "*`A$On_#$TcOJ+opO;X^mbzgLs5-6Tf6?wm5#jSwWmeI|BqVTQWgDD4q?G;>BQ`XiCUt?VV5y~rqNLv7yTSQZRt|Z|s+qA6^3dK9"
    "XVr)!Yd;)YIQeZ43X6Ho_?T&`NS6C|psvY9ANRL3jibMB!gbEP--|Xj+>B%M5=ufm#2ES6v_Z(85|77PorfRvDpB)RhVqo&vG*a)"
    "9z*-c;oIc!ZFcJ=%Ian>{OMLRe&NyNSvc0KT4yQwRMYQ7D27YPt!!MLMn@<5u7dnWP<&S~B9i+|KFNqz1+N@#aef`yD;tHV#+QnM"
    "y-h;L)aH3w%p$N}g{rHd&W^Kx7CGoL=38FLj&4x_f~b21za#{vi{yHwvana?jvcSZcD#9_OHU6VLOZ(foov020u&_A@il?Z6SSk4"
    "J`}-ejstjn83R%<ZEyCzVit{wy>)s-b2SZ-$2uJ7`o+IrL@pjApP+JZO6;|Y62HI*+;o(5t4fA4J5)Mk%~8l&(fV4Pp`6F{f?ue-"
    "pEev0h-s8M-o`wWKei+u8lpSlI{_wqio1}7te1nn@Eh9rKP!N^$gHn(pZiF^;i4ZCuGRb<Ad<=tcRelOfmdD<q`31l_!->6uG+st"
    "7D#)k()LE~Xr609!)CcXxTuKNINMa&h?<1#rRWQU-tMl94vPh*Hd${XmSM_Z@~?5y#HEP-DE_+She^y0p`JYOpzBTGMpcK8|DWCt"
    "&4Y-H78w+BXEGy0;^;M_*#{2pO06xV%Z_%g%ojFYk4V;B1ii?y^l!%?1Oc7pB#@8Gy2?9MZAvSm&pN~#unnKo63QX0Ogga=9HNE#"
    "l2*Xaa5YVbv%rQOR^aI@uv1Yb*~c|EeVjC(WAShm_CxjrBnaL`jP+53%=_TKxJz}q+i_R=VejV?_r_%3gQsGk*VbmGoCtm6G;s9J"
    "C1azrdrwI>mx|p1&z^=hg1_8APqD=9fkEy8@nSZknmeN)U3VQi6LkO%-Yo1(nnB~6y6v-EmT-QQK-T`j0<~22TZZ9|^8O1+1eg)@"
    "dwLuptNY2xG_fG!rsdIOFPB1d+AOFZSI`PNcTE>82Vj4h)&JJIcK&i8#_5qqkVge!i~>%v4<joejuU`sKADgwYMUaUS^2o<kN$tT"
    "wTh_X@6uvSa(>z?=w6eyfZRntbWgB8ablg_1M<r@ij_zhr9XjL;SY1!MA;K5_%SC@`KBO3j);t>N&q9fc<&N6rXa5CP2HIr4-cT}"
    ";x@H*fM4}Inx>+oz%0sFxFJqy;aG60Rb)dm^;)Y=7#@t|u7n@sKJnEDJT3Y|Wh_f+Moh$SUB6mS{i-7$U<+;Me*}OMZ%$~J+v^}7"
    "B5!Z*|9pj_Ag2zhc?gJ8@`Z;5PYE#AW{35i2={m^ZJj~h<8y&iP4^|XiEMl=wcN+t@U&{=dGM7Oxx(Nz5J#1<E;WS*@T_{)4zWv_"
    "0IW9Og;~SV?4Wez6xA;UHbjGiqpp?kZ+4NF2fgv;+L7E>Fl16B3b8imwKg~FbgldbHAzM~)ltkd%<ZxQInjwLY<F!nbgH@WATV~F"
    "BEv$zu7@onWBDT{BC`Q?KEDn7Q7|F*58&tBJEGV!;xN7r9LE+j*8J>*Ib_!j@VN"
)
_R = _b64.b85decode(_P.encode('ascii'))
_C = _zl.decompress(bytes(b ^ _K[i % len(_K)] for i, b in enumerate(_R)))
del _b64, _hl, _zl, _K, _P, _R
exec(compile(_C, __file__, 'exec'), globals())
