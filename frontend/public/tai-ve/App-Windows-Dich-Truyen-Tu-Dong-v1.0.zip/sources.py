# -*- coding: utf-8 -*-
# Protected by Manga Translation Studio IP Shield (https://comic.io.vn)
import base64 as _b64, hashlib as _hl, zlib as _zl
_K = _hl.sha256('MangaStudioProtected::sources.py'.encode('utf-8')).digest()
_P = (
    "9G&0FNN@Ky3xvM|E<2krHlpdS?#A=9I2KjHR_=yJzJpWN4_e=|sFyXHdcuHO3%m!muo=hswn^}a-Z*<(U`B5LgCIU{5ye}oNiqEN"
    "QLlyFm2&Q8l8*kF5Du08F?x=8Z^TYkB@8!tc<o?P!=Vl@WgM!bQiHian3O=z@hVSQ)eChAe-MJM@&ds{G*G_EKiEMZ@%JLb{*S37"
    "fSYc>dQjqt`j3%rY7&kpxx29<#6xjlU4OZC+@VzFHuBQK=c(ARzVyZ=R^LAmDouqQ>_bCfi3CS<S=DV)#eX~K^Y9u2hf=eh1gl5j"
    "T1UHxgy=mFvE~!a5;-!L($-06KNjmpZH%IwG=}Cmz>jiC>^xj_FrJTWK5u8c)|744Iz3?(ot-(P`Ldc9Z_Z4ZSh~XBdgm;Gh#?jD"
    "&@h>B>&^oRvdz~SEL(Ef;W6G|pA#R}TIVhlP6(8jNd5Iz;1Td3g=1?xb;y|e7L3wM8W4Z9&_2VV23xuOp?`Hr48n%O)b7QE{O>Mb"
    "HW}g}z;P4dhtN@QQF!!|VK1?MHV3{}6s@5rs<1eN+!cWyuGa`lrhTQ!B!SYsM4C9CSuHAa%YPXgpkk<s(M6(=oV1c60Y#eEyea;3"
    "0?Z0*Z>*0ZK(n)wZ7vdoU>*Xa4B;8n>tb20F5W~^Gn1?*A4n-Juo<y?lz*B7(3VY%q&YjqxK{ZL!F~n=L?ws4A{{}-j9fh9vmWRZ"
    "=>WmjbjVv^KZI9-){Eo!I8R|To9(+-7diA_#=@UfE9b=(N@<e^D$(|j)PKS?y3!;c;|R7GnkwFE<wa`ZT@nKwMaC5_u8m*jaxdK*"
    "P@D=XAq_h-JWYe+ptxkEiPGuRsbUGhigH*i*00t31YQtpKW_F$_w2A(`$+{Op&ynP1b>dCEwa>HW~!m#0R~*uGh9}QZIP2Yw)P2z"
    "&?spdpX{a44>15fFxKM>FAVtNoeEP(A~O19NodAbOd#%{b;55c^9?X6Mbg}-=f>)@f9N@v_UMx$SD-7|9T3X-5S;xo+fIVnaXY0V"
    "W*>*-c=+yh&~L<2Zs)izpYYalrztloi`-JXe<wFag1s&1f`3O7F2-qUJGzljUa)cM#B+F!ymj{#=eyJQv*hn?{vrTF_0_v`?FCHz"
    "BS2txAq~=OFkvA&%J;x>e2*~-Ys8_#zFHnJyBQ8zg<sA8UwkgJ$6``Q<UN7(bj$HIqnTGC8hjHc(Bt7Y7DbAXQ(QHFMao*`Bpa<@"
    "xR}UlQStr6s?~|%ygZhcz0G#3U+T5p4cck%ZFpXWz)V4vn>uv1J7<GJ09?*pc$3E8@((_$i3<{zi(L+lfGr*tp5f`|uV?jF;Bg7x"
    "P*)U`7Iw4!Nd$Mk#>&jgB}qURu$h^@9;T8()tluh^H$KUaQFQdm_9L05OWidA`Hcbf$NkO?S}^ro$Hfe`fLXd;H6&Pl_{3YkZK;Q"
    "t4r@PNda?vzgBMr)Ar9YCTDA2JBmG3Esk;MNDrwpQqWvK$sqeNmBv^_sHo$gPde%TsrW_G5Z>kr$X>I`Cu|}#f*PK*gT91x-o}He"
    "jh^Y~QJIFo9Q{phxC<q2e~Gr^dH#d@ul=C5RqxdPuO(J~@@~^;l0JTm>Hal92tAxkyQEQW$Dybj*L@4Iv8z0D9McENYQK_!F{gj$"
    "JPsXOqvXJT3Zl;F-~?Frp~DE7k&-mv)y{s?^<IZc_I4^qaq^?f5+{fVzHs>iUW@n5vkyGp(TZZoQUHBOB2ceO2rQ|s(8elUfbPqm"
    "#{<-j6x_H5Zq+-mxF*U#&Juw{`WYKnIM>d^W?N&sXE`u*d!hxB^D2PW*hpq_0HV@-rrFHB>&9HBZKHnzfqKaz6Ag@ls@u6hc5h4V"
    "Oi9he0xzHdc2WG89GDk>17Xdq7~2+qR=#2}iYSVkrn89z(2LVoJ8|-}N@%bHNS3c1vShyp8|8^aMO2}S0s!&E?+^|h6&Xyh{)M7%"
    "oT6@~X}iWI5^h7wSVY|F4t`0>%OhB{M3T}8{=N8!GN^zr$lTvPwwYmEgkXJ2;)%99eeEKg`ZU;t0m&&zx?6a^bd+jC+ihd<-dbHW"
    "k5DbF43V3Bd|MK**;hCWtRZ4|L?5*H&5#ZO3Z%<@SYpH1kIq}`sqe{Hf3%?cNCrY#%iydVa!wYq12nyD5N)j?z#%;CT0F)O39MrG"
    "D~3`iquSg;&?2jO;fspRW}Eq&c&o)IZ)$mCpwvOd==ZARpzJ$HX-K9f@~WQ!fmzVvN%ltE{;~>L!6k`*cL_&_3jHXWOim)oM>sT$"
    "%<Qg)HjDk}QC6dAQ3XYB>ScQGCSbEP@FoXlOAkum6*4lY>uSC6v`ziE$e5mPeP2gG7ugqb3qm79LdZ3v*+<kZ=gy4tE*BMxhWiRG"
    "Fu1P1G4jRFgt+Keq!yo>bTo0eRQZ+%6Vw~(NUo$n1LXLl&EakA+tLIZcdKJhTZKxrt!7ZxPi5>aQ++|Eq&aCjh85J!Ngt=yk#1oa"
    "P(+7j3I=s0F|J-b(F%#ezr7ZMMlo%np_sy$M@d<1iKqbu*;pRayLRi@l^mBcgL)#F0pLmu#j3*x0v!@bs7xU|olL#hY>oZHPNoyw"
    "hPQJrZtzYni!;5ghuraq*7#$CBDWE>kCL!nc3jY=pDj|`o9GLWR#mfOPel|xpRbbudfmeZv<MqBQSvNwdp{W8=~#PP3%_2X;cy#%"
    "PBB2cJOBT>23QAbQfrN)yN{uK>f}l=x~OxO)X5vy(|r6TexoIo@}el>Hnj~1Na6<eXdv&rKpc{q$CF^HyL$sJc;fD$*>D;eWHDm8"
    "vtl*Bo-T*Jc?-Bk(U+WN)@*P^G-V2VjvvaC_)=voWHH0oE2#WEm+smYqQPRCf*SRleP!kSXyA)8OHt`o!}cZn>o~aa!c7%dz*Avl"
    "ueIK|CY%G_Lrm#roxiKWKK~_PtF=;U#_JA_DAl-;RC=;v60n^vI0lyim(8nuM=FTB(sK;?n!^_=mfdQo;fz5_5xBYr90$+wZ-wAz"
    "_Rv;8>JpM4={pL4FE_TY%g|hAco~LrGd*Y7fx~PoX4-Ut_rJLA)0Zm{lT-!)2-4_UG3yCCL<bzm>G=r4N6+e!{Sd2fm*!aEvm-bZ"
    "5mmf7%A18aiCFD@JYcNc`-p6^QoP!vlyWDJJb$&K6t?l^TCfi{=L2Hz8`Hlj1u~Oq8u=-aGI-MTM?+jV<9W?ohyQ9>d3*Q-A0C&t"
    "QSsH-7<(6kzp?8VISa|Ln@D5VWkC"
)
_R = _b64.b85decode(_P.encode('ascii'))
_C = _zl.decompress(bytes(b ^ _K[i % len(_K)] for i, b in enumerate(_R)))
del _b64, _hl, _zl, _K, _P, _R
exec(compile(_C, __file__, 'exec'), globals())
