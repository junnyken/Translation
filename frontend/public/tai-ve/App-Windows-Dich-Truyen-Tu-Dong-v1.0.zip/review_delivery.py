# -*- coding: utf-8 -*-
# Protected by Manga Translation Studio IP Shield (https://comic.io.vn)
import base64 as _b64, hashlib as _hl, zlib as _zl
_K = _hl.sha256('MangaStudioProtected::review_delivery.py'.encode('utf-8')).digest()
_P = (
    "F*@w541)|m8oQwX_w%#)HlCBoDTdR+5VEC{$n6~UVQPQilOXQvD2~QlRuQ);azT;j&aYnN4zaqU6kWRNIDloa1Q<f8`-J(g=re0t"
    "8yVrxI(@?}M;^8pAIaF@mf4M`$wFTifR6^YqdF@J=6j%JAvFM(=jhxs=XO~?4-?aGu!O;=!-|`;sED`?U3)vl^zv)My<c0E(Hmgg"
    "&IYE{`KpmILXA>G6Av!BWNXfyg9Km}QX*|b2GP()#+q}vls=aq!Wk?<qRHv1=JOVaZ&lQGmg8>;qqv`LYJQQ9!T*!>$K0H$2P@H>"
    "pP`jnE|GSQTvbCzo%EG=O4)Sd93q+Ep&12K;RdPU7WAD*0O0wF6|H~@<S@1CI4C1a&UW`_YZx1uc3ka&i)?OPX5)OP5p@yMUTQt^"
    "0L;K8GqCX6#h7#8bNWT0b{7?A_ktDO<nBZul2aB@5N-k+4ydx{zsKQir7gVD6bL@!?GDH%Hrk32ayV(}i`s8kK?}ai?WPa=i5P*v"
    "O<|h!OdGV02UBXh-C?H&f#a~|Z;kQF)GJ4MdCP`{J26*1Z*Sb8@k$aR&Yk-Zc@kRez~Gr@sC+t&Bm+uW!LVxp#k}XP<_S4x3I30l"
    "=}|SdxxY>adi|V)&yGqI3HV*PCCcx1i@>RQJ(TAVbh&)UTI@UwxNef;?}>>}<+k<^1s`+<)YRP5OAk7dZ$~?S55f4VJ)C;Z9p8sO"
    "do7JkG#m6Xe8Y)w;vDgALsU2x@nu)kj1#e7U#~cYq5TpNKGmeG5Z?XE&B$j3?+rsEy^|aLBq<N8YJy;+S0Gp?(C&&h@&f@3Lfm@#"
    "Co5%YI*#q3B3nl}#p!!k-CV|BA}|ZL1sgA5&nh+vvu<f*YY@yYe-TP!4wgcxAU@6^vs7GP#2@n#=20HQ>Z6#tN3khyo$MdZs|H;L"
    ">o}{^y`o{HPZG-6Ub^vwmUK;>sAkdV6q2|w=gN`MQu{k$9FnVyG^(p!de12`8&0=5m#8tO1*Qd>>7&X1h-z|JWo(VD*C2^)9wXm_"
    "^PuC*`?r$4&_9-6dLm3wBr}OnEcX}w@#!xqc7Zyp6@QAM7@8Pe^f}fi*OA<wR)Nc=iy<}D+RPL9sX_7bZK>sK=tSR@3|@V=ez`<J"
    ")fME&pc)*naDUO`oeS$6AucAuXtAQ&W*tBVt_mwqo_K?{cXLMoC0QEo0XFX*X)qv;AJ(=&m6Y{PS<r%{Y!cI>sz2hK5?yp`Gc%_("
    "HRv~OT@ks=i2`lLiy^Ki@eO$lJFg5@dlni<wxYok=LbT=`v0Cf<54kur**nwuA$WY$2u3$=6&Fz4|lq4%h-|pNH6lGrr2(z873C!"
    "nF)<P&CgS`O(l7J3~6zgdFV47u(z@%iQUin5bEY5>J+|(VBbkId;3|Zfd2+-Y&H2c=A%2fyqmuMN3Nq4V@eJB@PDqAj(UFt<GGSA"
    "FpX7hgh*YVf8;Qbp_!oU0nUsIeXo|+hC2huI^B7;#W`PWe9*@0QA7ZU4;}ai1n1LoJNw|JS{SzE%6-PV*naAh(Od_w@gzDU_)PRY"
    "HOJA1|I?nY;pxqPRuSw`Dt(ooCnmc2z0sEwU}z|wndzm_*2jA1I3SMWUnee@l(2%o*50Qdj6bTts?jh=j&#AlSP?<a!j)XFvVO*r"
    "q$qh754Mb)nina6WerGSxb;6|O6JZ$m|?FTNC&Lj)cZITd&tlqR<#&rqLm_pY<U||Y{&XGb_E$K@n<QMp78brP8GM0|6V$2fvU1N"
    "vaRnwm%4CaTEcxxG!+hhf$xJY<bV@t-HH9;v>Ku<)*Uy^Tsie3#;*b41GVVH`T9_7E_xq!#-3n5^{kg5o~So~en|Ntc^*8c8FTlD"
    "L5i+AOdDp{^82<REa%m#hw=(!wH_G(H+jNt8bpI6TUSgbsG|={rYXU7VRl#E=RWhODj57>?eMsZlzGDFMHmU&smRtxE5(yRy0MSt"
    "NehNw<bxPYL;Cn`29)%wu^eUg1ntoe7c=-p@|m8LP=Ala6;j$DMky=rJ$Op#IS11Dp?ykE{Fd*byn*4Sp#dfmRA=wbcq0Vs_&FR9"
    "Q{vq?(OYq?3Tl?;xEZSxJ*lX?=oUcFbqOQ2sky7|>|(|X3vE|G0l%AoP#%!A+!+yAj4AaOPlLtm6|T50?b7HwKJR;S74ut59)9G%"
    "!C@UoKjnq{N<S{RoC?3^EX!4}2BamZzXF22^n85!Gfc!R4p&zXHYaPI*uKrgPga^Nbv>H;L+=hPE#kWV<%NQ77RVfK)8pdh&E<rj"
    "k@5Xsls2U;fL+<D{V7v|@Mrc#L?zClze7LuM+GhQyE|ZO@h5|i$j(0F0$Q>&8n@R-n<j9r=Bw`DbDDS3nQn%=W39ToX}n)&2IB~1"
    ")?AZcfb*OYg*Al+mm`2BTQz`7O@CaAJ0}EZAq=FzOL#Zp6cOR<))oGs1XUW~3BPRLz|*FCgr45?QHPYnBIZd^x4W}vqT*a_Pgxdw"
    "%>5H4oY-c|U5Cl2LtG!X+XNwd^G!HgV<*SOqH7s7ebAubR2%yTWa5wxsEw6ZfJ-h;-d-M{ijke}3<R;0{R^m{ejf?2DjHp^;}4_x"
    "kF~d;3oj{)x#Q&*kO*){^5Qg%!DsIz3@!sonOS(G#P-lWmcE%r&80Sl2D@#2XoE866JV8u62x}Q4m3lXb89BXe9HiQ-rN=5_4JE%"
    "nC;o{aTCfe>Huy>euOFFmT-YJvU6^@#sBJ7n<z4$06X*&RngpzZ~)}%pP&iX-WYkoN=Rul`GgC6MGa_mrYpRjNk|utbovDMMnR|D"
    "nd2hRea&qw?UW^+v$AEFW2bA7SR6cup|5bc`JFE#s7c~l`@<q=XP11GOMG>*ZIqM1;`gUlcvOMV6jM=!lgfiXT6Ucsi?31LWXGPC"
    "%*oIrQJNK+w6HYhU8tWfeR5$+n^9|(i7<X)GqUpl`yz+>79B$E_w(OIZYqfP&}hZ!n=yy^Vq)L03_FSZlCwDvk|5rdOvd0EJ$92+"
    "*zbcT2xIugWB_OX4U%8Ma?-Cn`DLiAv*@+X!rT2txPT|4kZwLUAMAkF5S~1bq<$GKxsu_*+{lSLAGw`u;IeGXVm|~CvIul_7VPz!"
    "5aBc0agO+$yfWBuK9wXB5S5B(B}?ZbEh)OU|A5oEi3v1M9m0hIrF>LE;4XWf$&uil;XEC`Q}-s==V>3?;d|BPogYje?Dh`CIPmo;"
    "68%o0hvFmnIjn0NOtX^B;NH<xK#4P;Flwtu%RO(vx^u_KU#n1o!^1*>vMv)2q}5k1CaD=QH@e3jNzKQBqSdW1cI8ErxRc+>1pQ>3"
    "Ew-eja@hE)o6<k@0sFD;Djy^RxF-<n=m(P=>QYjmPsQzV`L5Nmy^#VR>717sUW?>(wJ|O-B|!7iK+LZR2Q|+no476GnL(pZENJz4"
    "=fcj;$C;`!zUbLi7hxtvzZNwG7$ZkkQJ%$Rjc3VjgQ!ii2*^=P6c2g%O)Aj>95<z0xrS0p#{^$w&8RN3;-_Q?PkIt2_i`DKFeO?t"
    "ij{75chh@g&U|Rcg2`LRQOZ(?aC(#X(R{1k67KUVLlF!%=JA!N@43Wn#1!}oIm*CSO`-f4?3u=fo|}9+<OVR!&0qM4EQ0(0Z-1ov"
    "Nj=gxr1yYCHZBt2I7I9u9$(Kf-=e3uR1yzPO_cG!PKg+Hhdv81^uVd|4em=OhBgcH0AOlRu~!VGNf_LxEvM%a2k|=Y{Uif}C%yWh"
    "JW940N`M3rwY}<zHTqhpJE~oS`NXWOo6tk;rl1OX9>aO7ggOj35{GKBSdnC)4tb}<d)avtf+3r*1lBeqCRUH}AoKQI=s2gUM6Bmr"
    "%7yDS3mQ<<=K9SUr%9`vj`pve9KdUvS$)z_oB;K0I%kbJk6c{xTV&Esal!hv_tt-N0Rpk1gv5bD*@3|uaV;Ji2)O"
)
_R = _b64.b85decode(_P.encode('ascii'))
_C = _zl.decompress(bytes(b ^ _K[i % len(_K)] for i, b in enumerate(_R)))
del _b64, _hl, _zl, _K, _P, _R
exec(compile(_C, __file__, 'exec'), globals())
