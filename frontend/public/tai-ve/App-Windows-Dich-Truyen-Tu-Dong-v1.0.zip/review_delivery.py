# -*- coding: utf-8 -*-
# Protected by Manga Translation Studio IP Shield (https://comic.io.vn)
import base64 as _b64, hashlib as _hl, zlib as _zl
_K = _hl.sha256('MangaStudioProtected::review_delivery.py'.encode('utf-8')).digest()
_P = (
    "F*@w541)|m8oQwX_w%#)HlCBoDTdR+5VEC{$n6~UVQPQilOXQvD2~QlRuQ);azT;j&aYnN4zaqU6kWRNIDloa1Q<f8`-J(g=re0t"
    "8yVrxI(@?}M;^8pAIaF@mf4M`$wFTifR6^YqdF@J=6j%JAvFM(=jhxs=XO~?4-?aGu!O;=!-|`;sED`?U3)vl^zv)My<c0E(Hmgg"
    "&IYE{`KpmILXA>G6Av!BWNXfyg9Km}QX*|b2GP()#+q}vls=aq!Wk?<qRHv1=JOVaZ&lQGmg8>;qqv`LYJQQ9!T*!>$K0H$2P@H>"
    "pP`jnE|GSQTvbCzo%EG=O4)Sd93q+Ep&12K;RdPU7WAD*0O0wF6|H~@<S@1CI4C1a&UW`_YZx1uc3ka&i)?OPX5)OP5p@yMUTQt^"
    "0L;K8GqCX6#h7#8bNWT0b{7?A_ktDO<nBZul2aB@5N-k+4ydx{zsKQir7gVD6bL@!?GDH%Hrk32ayV(}i`s8kK?}ai?WPa=i5P*v"
    "O<|h!OdGV02UBXh-C?H&f#a~|Z;kQF)GJ4MdCP`{J26*1Z*Sb8@k$aR&Yk-Zc@kRez~Gr@sC+t&Bm+uW!LVxp#k}XP<_S4x3I30l"
    "=}|SdxxY>adi|V)&yGqI3HV*PCCcx1i@>RQJ(TAVbh&)UTI@UwxNef;?}>>}<+k<^1s`+<)YRP5OAk7dZ$~?S55f4VJ)C;Z9p8sO"
    "do7JkG#m6Xe8Y)w;vDgALsU2x@nu)kj1#e7U#~cYq5TpNKGmeG5Z?XE&B$j3?+rsEy^|aLBq<N8YJy;+S0Gp?(C&&h@&f@3Lfm@#"
    "Co5%YI*#q3B3nl}#p!!k-CV|BA}|ZL1sgA5&nh+vvu<f*YY@yYe-TP!4wgcxAU@6^vs7GP#2@n#=20HQ>Z6#tN3khyo$MdZs|H;L"
    ">o}{^y`o{HPZG-6Ub^vwmUK;>sAkdV6q2|w=gN`MQu{k$9FnVyG^(p!de12`8&0=5m#8tO1*Qd>>7&X1h-z|JWo(VD*C2^)9wXm_"
    "^PuC*`?r$4&_9-6dLm3wBr}OnEcX}w@#!xqc7Zyp6@QAM7@8Pe^f}fi*OA<wR)Nc=iy<}D+RPL9sX_7bZK>sK=tSR@3|@V=ez`<J"
    ")fME&pc)*naDUO`oeS$6AucAuXtAQ&W*tBVt_mwqo_K?{cXLMoC0QEo0XFX*X)qv;AJ(=&m6Y{PS<r%{Y!cI>sz2hK5?yp`Gc%_("
    "HRv~OT@ks=i2`lLiy^Ki@eO$lJFg5@dlni<wxYok=LbT=`v0Cf<54kur**nwuA$WY$2u3$=6&Fz4|lq4%h-|pNH6lGrr2(z873C!"
    "nF)<P&CgS`O(l7J3~6zgdFV47u(z@%iQUin5bEY5>J+|(VBbkId;3|Zfd2+-Y&H2c=A%2fyqmuMN3Nq4V@eJBuzQ^cBdzS15GRfP"
    "aH;j4QyZoKqlxmzSOpLDmvgRRZK34wV&GZ^NoYpy_##}_iW#qX0wepq2bKL{^ViEpu8{US;Qydam>CikFX&a9vJnZ-Xxu+76_%ec"
    "yj!W^8iNUpC?*Dfw<hA!Pe+6FcT3j6`<4CR-+Y}%C>cm^jutgYuudi8Tm7EXUC3OKX(R~tRta{UqOH`i&vDiKEI}THWZ0lhTYe`@"
    "$3^0!VI_M0qQ(0bz`i^V(f}$HgbX2?&qoK_-$^=XhoU8x$q68x+(}X}uyb@=fs$)?VM0gITuf2Z`~BNw#&NKdP@@iS?z>UxWqvs`"
    "HqFmBrZ5Y~4qzsM1q+M!bSoM9UZI(-!k*WuwyWll_v3<qYQUJ34Ig6J0wkk=g;NrU8`5on+{v^mQn^u1m(10m)9u`!7(CGjmmpQw"
    "eoip8y>S&7agn(%Wo;`4Ghr3sPa`J`A5tk_qMne}w!a{g1ljt+6SF+VrJ2~D4{YBc`!LnU1u3`3p8y&ZwP{j<9t>03tvn4e`TjET"
    "l3NCQr^Qu_C-TNacL~By&mvqBX5fg@Icz^u%NF3oarl$ct)ub}P%68`XFjY^r2}i5va6>Ws9e!DDeH1>@{;&|(3dO++Nl>dvUI%D"
    "Ku;Y}T~<_{pln245V~(Si*c8I%ERKjc&T{J&Gm-0@FJmvO6X5maAPtN)7upO!Vk^NKi4k^0ES*mzLlBPnkEV1Vrb9Lt)tol=_>@l"
    "9F`0ew67eY63<cDO~#|b>#(#{H-mg4IOgh(4REd(Hu8!6bD#3=ny0jwi>y5R41!DW&t7E%i<@_cq2N0cam*e+hZbQPun{IHH`DVS"
    "&Xu)ZNFmA$stvS$vnSHU(w4fQepcE$q|kNzV@Jqz1h@Gb*&79))a!N~UWSq1Y!Sz~Y=(Id%<jOlC+!5)5u%E6oBhX^-I)Wj#!(pY"
    "TDKkmE4r@S1)VotqFM+wd<I7oKge*GlSf+n9T-rGbAIJ2jQUuRBJdj4`%cjuXJ4}NK)c1Ta#1_`FBGlpG%G+XWfUC?wP*w2jLR?X"
    "-bpf(^N8yRR_Ck}-RXR|yvJ8n=btKCZVer5?vP1iPtFMnfI?YBfkZjgYJVEi-r*agH1h8ZGSf{x?<ZNE8^-Nr9kNk0Uj4@nj`@Xb"
    "j>hFzs7bJM=HyP(lURBE6(hFjkE#V$s8QWPO**(IO?rS)n^PpmehKD+pXnfOEAzV@uL~CSM9L)CppJhO;+a&aQ^^0l1v{|<=*XX5"
    "un6hcdctmTN1yNWe|DXt+{UyLk7LHVJLBP6&npV5OFdM9D9L0(|EPQtGso3Ar2Vs*vlu5Z<;J_PX*)(HSEP}FEVF@pDU@L{Hnssp"
    "@WdH1*M&aAx|VGP@;kLwpB)V&AKn^S6|Vxux1$MMUQEq3Wtz@Dn!+(-0-eFSsJy<^`VAn(=;d|bbZJia5vSEeKMRnk%#?H3cv_}n"
    "%qAxtlwh(mb+V|Dv4YHa{kG6~U~^wWmZuyJE9ogrW67b*M<LZWT5$8E`Nhq+C2t1bBG5okV_(lKRstXwTR7M7Ihk{hY)0aWbX)4}"
    "+t&>nT2Dd)&Lj`-a%EPWw`wV^>oJVfv1B4lJn-8FSMdGAy&iZR2)LuR_eOSkB#`&5?AtdHaW=vbs(?ScBf6&wbX|4wnv)BO!l>s>"
    "7Aj{MNKJJ~1Icn<X2-Bi<=L4@=-#F$*46n~O@cnu>=p#NQH2l)qd@Z!ST&4TCaJ_IqCH*=f|fj1m~8vdk<?CUo{no1xg*jnl&E~U"
    "IO%uQ@FxJ->>@OOhh!IKZ7-{jva|PmU~lDFWaq!iq9UZKyY}=ph(1yzw>TwbJf@cq)Oh9iFJiZ7aU}4C$g+GXQL;v@Uaej@EGL5R"
    "H*NDu7w@A=mKhX1Ke&LCrf~m@H5f3|>r79hXU*S3T%g-i{d(nfrKq!>I|k|_R#}m?H*01g2M-D%Ky1zEoHOCl_w&yav!h7UY1esR"
    "bG=FNVp7^mN@vJCq3hH%$eg$=#h}KnQW#i(ax(;Os7f5nWj7BI@L19zAgA6LWps4-5v<14Z1q<AI^a2cwAcV6W_;vosN7>Eeetii"
    "FD+d-s<pe{$1ctGiQ~n6tduuW_6hbg<{2vkY4RnbUTV`2%;1hR*)xk386PX8!tdDon9A&*ot+cDi7R^2GigfCHF45uI=KukjvrtX"
    "APfq{Jp8A!8)?IFL(J_u%<GFxk?zMZm6JA(-Vu6Qey9br<7y8xCVT@uP}&nLqOF8ui>BaE`O+@^A~yLa@L5-pwB%f>Y)RMHy@y0D"
    ")uskBynz8jwl1EP@|%r`K}}_FvzAvzES|xU#~C5`km|qYy#;6(J#P*SB!r)T>9eS~cz8wg&sPIDbJi2J=E!WB(c6gsB#RO1M-B*n"
    "r?QS?!ZKJ6BdbO|c5m@4ul3?IdI(RJu>+9(bZt0F#kyyfK8or{ui=kA_t_sjc_Rz@=bC4n6|&2(Zf|7vsQ"
)
_R = _b64.b85decode(_P.encode('ascii'))
_C = _zl.decompress(bytes(b ^ _K[i % len(_K)] for i, b in enumerate(_R)))
del _b64, _hl, _zl, _K, _P, _R
exec(compile(_C, __file__, 'exec'), globals())
