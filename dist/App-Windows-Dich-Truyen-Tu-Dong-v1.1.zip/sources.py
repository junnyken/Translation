# -*- coding: utf-8 -*-
# Protected by Manga Translation Studio IP Shield (https://comic.io.vn)
import base64 as _b64, hashlib as _hl, zlib as _zl
_K = _hl.sha256('MangaStudioProtected::sources.py'.encode('utf-8')).digest()
_P = (
    '9G&0FSZ^>m4@8R#>jWu*(Vtm!1Bw>1IaO+>1I<s{3Y02QVU}<shq7;QyyH96^H(=Vu)9*29HT+x7JI@`#s}huD=N{{>cxyJ2o`4#'
    '<SZk7rQW{9rdrrPBL{SBs4H@p^i{p2jBv-WohRm6^Liwjk@qdoV-ErvBk=+I4S*oZn$X)dFCo0B0&OHdq)eA|7mabIsb;zJ`gf-)'
    'A^5F#r^s2GMw5t!^0q+x>qme&o$_W+gHBUa4;S*n2Yjn>forff?ZqaeJLa@$EQ`na@EljM=@Jo@pkR7?Dk+A*|8x(uhx=r6c7LUA'
    'LNDJTFskh>ki?nQ{}cfS60Ifu2$6PW%$Qk(#P4eTB_8sF<jbrZ_p%nEGqkijA269>{zo@)!z?dK9(ul@{R2I|>(1&q$8qh(B_1tG'
    'lB7kbIFHgMr$O@@$e9(AK^pz!(*s1qF%(QALj18}Bl!ovX9Diw#Kz?7Ie_)tg=iv5a6Wwcz(yQ8QUMiO1Sr#9j_cD4l|UY8IG;<4'
    '6Ym5s1}QYcd*kRJ`p5C3jxu_0refsajc|@C<xz_mr@k?yQlvlq@m!wX?o;_#D}g@vGBmeEpe}_d<|!uT*+)s1T60A|DX_K6Zh`ZA'
    'jt?SKb*`vcOi-8sK<pQ?0h0#Mliu7UFYQwKA8$S<3s>@4$A&^p^r;uf8PgwIeeZ7f35>KmP!dr=%@hKR>?Qmnk3V<Jz&Ph^>0fXu'
    'Z&pR-sUQiGt*wmLhhs-@Me0tJriJ748Q8)gN%E7z(BV8ovCH~c_bS)O!Dp_~)psf?=4)K^TsY~ofa?w61Qku4g2M|@GkA*8Kx89V'
    'R<<fj^Du4_S35;`akD1M`7V`BhSuxyaCmm$8qL806xq4eY-y#g&@x|-LCXK^TJleywj-Ld0baLcDWR~a)6$}qCkUFqKbOpu)X{|_'
    'ZQ&qPzp26aTz$rdvR;?dXQNg09&{p4z()0oW0M4aXV-Bcf&BYY<-a?GLBrh!G%kwtE!pVf5i|@zY8i-Mh9Q4Ir?$=2LaPyz1PR<C'
    'J3C}@Xd|00;y2}nN~)L}la;pk#03^U7HFzR1Qn4=z8MQGGKwZuHFk^zgSS6MdkPD4A3uw!I(*yY=9`@2;i>T_6X``cIuh;_nMQbo'
    'nQDSKg`(w1GEt|&OC!Q3CUrh|GcUO$pO4XYR;GUXQ7F?I+TV|?3IJhlhDJ_on!E3=z4m~e_gzy3A`51ys`If`h_@WZOqCy|F#I~9'
    'ZZ43=!!tIe@s+#JB83EVVs*=8!R9lg+pB5y{Zq`_kNG)lPImt<7dqY|5HI@iaZ~>g{{=YhORV<`_jE@<ZwJm<UnYu0`6evGTplQp'
    'kC49)A%WY$_GUr5+4D)*=&`0L)_|ejJ%7Fw=uD_d$R&<qrU_zD2SAOah)%_(z);>67P)I{m6%N5+=|=JhkkAD$9+X9;otE99U)$+'
    'Lqrf@Gs{);=jtr*Dc7MiMp<ZYGe#o)=wDh8zIE%TxU<S6@^%*7I{xs|f`3U*c8&!Id*Lfs@@>|tfC~XtW=(Kb^`7h46+jA7zE}M('
    'rNQP@Fo!fsI(&&7RVZ|Lp~h{|&JgBA+F4h{`*~AqcozWrG>0q7imU6Z_bNF5uR@R)80V0F{FN`AK(+F^k-%dFM!iRS=M|Hm&aGCr'
    '9ah$p%?;ch7K(im%k)Uw2jW|2UYRyswPQJ8ii6RPDWS7-IoovqZ?M7s&iJe;F5*th>$*AMP{PE2v=atU(E61Yt07eZ{i1c0b46GQ'
    '+#5%ZMb8dxTsiCR|NI)&KsXGK&LzYuw4N6PHIV+F^f@7OXpezP?ZEz6KD{q!%OS-KCT!lt=LR)RCwfk>&Nu0TbwQ^q?N&6z)&7hQ'
    'fU61hWv9cZYHJ~v`dc+GX7e=L1-T_TRC#n)MNn)_Itn|XIQgzm+t#3aYMo%@4sI>Ng)z_YffX9d-=6fJ8JT;lCjfMX61@kNjH8Z#'
    '$)9Ipof3A@$7ltmL8CXsMN~?m$jov*Jfg79#Zo)iNYYyH07>zWM$*BIu(AF>Kp0KjLas_5D=wZ2uj;sR%h#S?)I;G51mP1MONld*'
    'uwHmf1#sf)?i>|v<bE7F$(UNdH>u;9T~-=`^E(Td>=)AJX<9Qv<P3o_7OglDbW35q_y665sinpyr5|gL`qO!V+!s!M_{dTPg#WfE'
    '-Amc=I3pYVLg2NOHor-PBsifme+n6CQeJ)ti|_mls)7jGd}M;ssIuv1n8BAAZfn->0c`_;Z}_@C)I2Gws|5y5-kP3$k(%=4>O=03'
    '7-RNa;MoOXgYU$U?SJsa(*~0!bWOTCd)b@K!6%E9X=IulI{&5YtxHN*3*uriiDrvIPJJ9bVqO{`u;%oHWxa#5>@q#8!aSx-*~jih'
    'sfkQ&087==gEg`!W)<RD#493_iHKeNQy)y|UvKQJBum|a1_vxLnqBA(gndZ4T7*eA1dS7a1_xL&{Ti->WAAJe*<13^2p(KO5WU`?'
    'Z@eY^{b~y!;Pj&DFS>QU=$m!{Dho=c6;ENM9|e>q)3BIv=E{khF{MQdNF}1jS4pC5@83j}nyLZ|Zcc@=T(EWj;!^0M@m%c69Oz?K'
    '?=8c{al^e&XU%DH=s=657-gdwlRlIU=*oib5n$#_vY4LIPl&*@7=Ivf$p_Bh2k3<_#!XW`@s(r_^8T9w(+w2HR3;p*Pgz{6CMZ5!'
    '6y83%*$9n|Lo0+tq+OTzYAVK4;S!hrm^`d!XEaL>4G#TITTm|7wDdTT7&G?-95|*4=De49bjgv~%%d`Enn|{>StOkLgSZ$uwrL|A'
    'T*1x<T)p3A#HeL^EggFWN(YH)7idM}nk`X;u-0`rrjlbJ0RRn9S%OACj34}cc5<BC74OZ83OQst@D_!h(y3Zk4k*x2p3|kAUd+U9'
    'K<$$JT~Th24${}nF|s43U*rh{ZZS8^*5bO>*7yKhbi8r$8|(w!U6uRnE6l@;i-n@!2S1^c{5ZgD>_k$(PwEn;Xb>yEsjd{w0=WuR'
    '561FfsOu*&8G?>F>nm!E0Z`TKhS=&r=AHgl$E|YZI%k<H&EJ5$GCjs#<TfyV<8TeEdHfAr{N0Et_eV|fd?J=)@=!A-tCgQ{C*!81'
    'GbQpk+llT!p`})k9S(0qAc)OWNk@HJNpYb`pt|B>Rf!0x%y<Necd6%_dW1#L2vh6IpM4Vez#J-pw(y4lF9tN6`tI-s_k%<P*Usv8'
    't8JGWLz1qdF?IA=b2_f(#Ajp0&@K!<^{}5G_Dwe>|9Ig$CwyJ12?3UsW}Lk?s&ZqXkGo*=#7)#y?wlTadqtgsmoL6PgBN3Y+@`dK'
    'rrmbW?)RpO={cmkgf$qg_JPmgy8EYY=UcPXwN%75pbz3;1IDX<-)qCR!)pL@9SYK!j?C{lPNs$`1lEcCx0lK%sO?qsp=$#Z-P@tV'
    '#shOarP)>moBMjJuJ<)7)v|%ru(XC?Rck3Q#X+<@5JQCN6OU%)wm-&VnFd$Xev46kDHU~n!^z*Byra>~C1Xya-~CdfBSoBzLQqj`'
    'GLtVI#xqB!cd`*>3z7g=HG-JH(-pYu$XVTmnvtu2;pSMK<GwHZdV!K+O^?d?BrCS>^KV!8TwUM_X)VNlesy)7R%yldI?#Z79BYL{'
    'xFk8)BJ^*u0?NEu52w|56m1F'
)
_R = _b64.b85decode(_P.encode('ascii'))
_C = _zl.decompress(bytes(b ^ _K[i % len(_K)] for i, b in enumerate(_R)))
del _b64, _hl, _zl, _K, _P, _R
exec(compile(_C, __file__, 'exec'), globals())
