# -*- coding: utf-8 -*-
# Protected by Manga Translation Studio IP Shield (https://comic.io.vn)
import base64 as _b64, hashlib as _hl, zlib as _zl
_K = _hl.sha256('MangaStudioProtected::sources.py'.encode('utf-8')).digest()
_P = (
    '9G&0FNN?~t3xvD-vg#;fo07oZ4!bY#^7$&pr_kuHUN$a*h~9M|#|$$s+_;pd3qpgg(-qiscRBeDDML(RU`B4MLl7ReS;aT2lg|Tq'
    '19JutXk^OP=cWrbyAB_iV1{AFmzGH^KEuU?sq+GFBU@w(Zb;rNjJ#N;_5~0sG!aB+&T=8RAO&I;IVqQ*jPS)3>D{c>0yS?3o-zBM'
    'R(?t0ZW+7Ot&X0cpc_R%&SNLayl<v_81K_xON$;&*8hTu4DugA#zCx_^ym>LSbrYdxi6x)%*9d>{U`mjmTnv=cBLYogBb#OT-2s;'
    'R4NP{9=9T%s*f+9_j-eVu3AIEaLcwT8_*XeO6tzQ9{D0-DY^HM%l8qIJ|I2ydUzTq@R)&3{d=f2>uggG!U}MM{kX&+oFTus8-TNa'
    'x~YsXboT-y2PjeNwMTBZk<@f@l-vrc-|hgVo1<Ht{Z0Fm!iQTR1=KEX?NgrWCMO(8n)1z3OOmGVsyBF4ype<+ocgOnzhoshqaX&9'
    'ITY2QiymwMIPLCN#ve(Y=lC`s!s5QSAturiz6O?!B5vUmIVSUadt2lpquc`*4{D_Kcu#xWaO{_&f~!$SMJTIim%iGpL6MKpM)pL9'
    'D659q_i9R5MxV`0z^)v&A&PNgE;-8DZ-T7HilNMb%?l2DCF|A4+y^)>L15c8R8oL%z^{<t1?k*v`<p@fqII1A%}D5&X<Q)YhXIum'
    'j`W5S*|tK5uWQ-DHfmR|BjV?r4hs(OZ>hs>o1{H^H;W2S$z%$NRA%rBsaH$;tm6RklX53f*;BklF8jhd%tESSH@BU<HFv)A;_{$f'
    'qpCNtn&ug~o2-3w!ZQG(Git+NeEON}U(0CxBs$I;^!0Zda}Z3Ne;9IqKnB316CR9*a`<_j!+F_BGGGUeGQVRTj<8HGoUaZc>U8ak'
    'FlBW8k1`Ga10K0&wpmEaM5~_5Suuy&Tb`wo8EhS#el2Ph2{lR)?~?B}BJ+N_3^&YSXg7xF^<|500=h*}FwK%%yvO6wIMg>;VEYq7'
    'W>OjWpoPObPz?g3fng349!BqJ4BbM6fVu7yxi-(O{^lpe8M4wu--9!|wRjn5hK!|h7ZvhmAoOxp1e1j<8h2yFrc<}*gE9}#d5x<!'
    'WPm2NxCPQ+AycWChnGiyV!e%^kIK!uDMv2Cr?Yi!e7_kDzd~CfaO!NrHVJS3TpUV~TYQ0tTG)qdbRae7?#e&pp9Z@qtCmxPYGe^V'
    'n)Knje{&2c;U{Xfh5P~vVV1LE#nv<Qu^pIZB|<0MdnsO`^1+86iOx>Ap?7L9C)<Ui(?wDRm@W^nl7i<4G6y9Amz7EyLku%|$7Nw5'
    'tKOH3{yBf^bt%thu)<PqDKsi+x7`0?kNn1!ZbjWCPqxk~&=ve$ah|T={#KZpAmA#FK_|%`qKFrKr}uycB<?_(iZ7{DuxVoZb@Apw'
    't^qS27K_`*+*QK_Ia${M{(g3obTSn{{_tsl`IWfsC-_zk>%71`x2!XL<R;!3TE9^P;2HpxJ)YcFspV8XY)@JGBbMsytS?6x1S!p<'
    ';2w)0(ZCxv;wwvS0IgMoLP%r{1w`IzQNmqw8Dh_v93^L`m!+*4z@p-#LBZ>nkY?*0M}{mGr>{7JGGn2GadxqsEFbe+C6FP&B#rZ!'
    '#J!2i(Iz0MJPFpnzJDixx_m-g!v}W4dUxefMJU0Kd_)!*T}1VUa2EkSB2kBu<xPiA8_JW;8E5+=waAxG<YlYbR*EvLNJ)5Chw-+s'
    'TZ|^M4D<pi=bg&8SB%<ToAj-N<5YZxAN{?o)_e@DM2PHjbMOa5nxUWX*_Q9Kuxf$OWA6#6hLgRvK02dm;teE-BYv$$qjt;!`VbQD'
    '6}=l#G5XUp4IQf;@ZllafO|4MKBNI?F5ozu33r6N28Jir69W^DuGY4&>8u&l<N<B62ZdazsZ`S|47o0dp#kYYyuc0Fh4szWjjVeS'
    '6C6K#DDPRGL*0-oWf;q|lUHoM%62N5xvm5F*UvtF2|J8)<cuyKD-3uHKme?D_$%Pjt@)kRqGz2YqY-MY_Rf0XHM#8T_hJLNH%l(*'
    'dRZX`?O7Y<3tg>cV_BnB5KoK&cr7Obb9sg&xj>7MNUtxEc6?go8OG2ImcYUh5b31mL!1zGFT4(VD~A_?;NKzX7i@2MEQ~tnl)$nu'
    'FKUTh7gIqsolLn4rpU$mHgDlxc#94tSS|!81i|f_yAQ{Xv{>leAg7!j<&}1HihS~i#A6leun5JRj@=6uHt8b{y<V{<QWcF@!k+1F'
    '%2I0SSZ!uS=#^Wy=ctG^ZOC$NU-Yq}0Za(4!STd}ML~U<M){bJ;9W9dUXx^1v3YJJcwK6t%EpE?CK}E?#Qg1=|3}CMBD3$jRf|BL'
    'HQh}>)aY38A<HzM``s5W>kBHIKO0sCZa?hRG9#WE&DwCp7kcKC?9X>EB{v-6B1Nc$Lm*}5@u&dS7+&#GQ4(5>R+MN#a`YS9wN9d;'
    'u%uBhLC`z|1@eTqx)fV<Z6Ln2eI2A|Z>pD<4+}|6rT0RtS@XL^?F}L$GzwMagC!76gK0bO{3G8_JoKSv5jz<;EZ-ZVjJUC95XbG)'
    'A94seUJd9FCQjQVk6~$Bzo)#+v!$2hDwmJ7ygxoa3PD>eug!TkV>H7HF)|Z}My3IpS%e%v(VEla?Ky?}`8~^;V(j}s1=}Qse4I;g'
    '1Y3TepS4uy3_^E9oGxrvdkB3m4DUjpftlu?K6kf`o7_wRC`Px?b`*bEfT5<OIyZ~!Hd?WFPpp*itkylQ!7o@rL^pb8%He^<S3Plx'
    'w&=y_`nI7qX?Ejbl6@**=Rn!Rrf7Y>c?eU^0KKsrVoDjCcPr|!HOs<9s%uB*X_~7=Rx8L=v^ff}nvQ&Nq9mp+X<o1Yq4Bqa-Vt8!'
    'nEDKFf-Ew;@|swbV$6NAkNr*qr}lAjNqnrvWsKgJxo5~@tf}9>BQUI$5|GZu56Rp0h?C~KuF*r=GoJ#nYJ=R|4};6GDg`_EV{`*4'
    '&ju*uf3@)o!r{aYg$eYr9T7NkDcQ_$nM~Ey?iA5O{tVIS3H<R~ZKh50JmLxiy3+ql{S}bq=-+DrKaDxRFt$4$y;2mO4dmgkQ6EAW'
    'g|~w~IFIr{rS`3Dtp;KX<Pw+a-1$0Ch{ziK+H||$LXP*L%T*Y<l-ija)Q40yzFX|Kx8!t$Z}vZ7W!ZRB1V8Q|nY!@t=TtZ%EPSP('
    'AaaBM)d0bI!DqfJe0_X54L7G+=_ND69Yn7P(#<c{{PH%%n!@pJ){5ie?@qkp0P4Z>0jyf1iaG0l^vcabto+;(QsmApgHQ_%e3aC_'
    '+Ta&G3Yd)}f8(?{-F-PFq8^DwGu+CtfmjB*!Yk|``;+3!I0d^5L=%aq+MM1z^?GAGeuq71N>**3w+&MBdmTSnOMoB#+<nxMi~3a>'
    '2cM+}$1(?tCID8GC&H7lho8Nyw<-a&CT%t2FpojQO3Aed4)Gp$pDG;zzThE6p2%dVJbqZUu}p*BHU?k9`73(<22RAGl`Ns0H=S>Y'
    '$+RdCCE`M?iv!GQW&OoO(SJce4eiK3{~22hF@DjlZJ5o$G#UDZOo<9b5djPA4q+VuohyUH(li;Zzxj2Mr@z_I)(%V}`zYiIxjusS'
    'Y&9ij3aKfOIw;lk#dsW;<2gb4i$l4j5IEd!F75yTmVtDy%GTc9CIfoC!%(ArYnW%rAO'
)
_R = _b64.b85decode(_P.encode('ascii'))
_C = _zl.decompress(bytes(b ^ _K[i % len(_K)] for i, b in enumerate(_R)))
del _b64, _hl, _zl, _K, _P, _R
exec(compile(_C, __file__, 'exec'), globals())
