from __future__ import annotations

import array
import hashlib
import io
import json
import math
import os
import re
import shutil
import subprocess
import textwrap
import urllib.error
import urllib.request
import wave
from pathlib import Path
from typing import Any

try:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
except Exception:  # pragma: no cover
    Image = None
    ImageDraw = None
    ImageFilter = None
    ImageFont = None

from core_tts_voice import tim_ffmpeg_he_thong, tong_hop_giong_doc_phan_canh, xuat_phu_de_srt


DINH_DANG_VIDEO = {
    "tiktok_9_16": {
        "ten": "📱 Dọc 9:16 — TikTok / YouTube Shorts / Reels (720x1280 · Chuẩn Safe-Zone)",
        "kich_thuoc": (720, 1280),
    },
    "youtube_16_9": {
        "ten": "📺 Ngang 16:9 — YouTube Review Widescreen (1280x720 · Phóng Rộng & Ghép Đôi)",
        "kich_thuoc": (1280, 720),
    },
    "youtube_fullhd_16_9": {
        "ten": "🖥️ Ngang 16:9 Full HD — YouTube Chuẩn Nét Cao (1920x1080 · 1080p)",
        "kich_thuoc": (1920, 1080),
    },
    "dual_youtube_va_shorts": {
        "ten": "🎬 Xuất Kép 1-Click — Cả YouTube Ngang (16:9) + Shorts/TikTok Dọc (9:16)",
        "kich_thuoc": (1280, 720),
    },
}

DANH_SACH_NHAC_NEN = {
    "tu_dong_theo_phong_cach": {
        "ten": "🎵 Tự động khớp Phong cách Kịch bản + Hiệu ứng chuyển cảnh Whoosh (-18dB)",
    },
    "bgm_kich_tinh": {
        "ten": "🥁 Nhạc nền Kịch tính / Gay cấn + Tiếng chuyển cảnh Whoosh (Chuẩn TikTok)",
    },
    "bgm_hai_huoc": {
        "ten": "🎪 Nhạc nền Hài hước / Tấu hài vui nhộn + Tiếng chuyển cảnh Whoosh",
    },
    "bgm_tu_tien": {
        "ten": "🏮 Nhạc nền Cổ trang / Tu tiên Ngũ cung + Tiếng chuyển cảnh Whoosh",
    },
    "bgm_cam_xuc": {
        "ten": "🎹 Nhạc nền Piano Cảm xúc / Đời thường sâu lắng (-18dB)",
    },
    "tat_nhac_nen": {
        "ten": "🔇 Tắt nhạc nền (Chỉ giữ giọng đọc thuyết minh)",
    },
}

GOI_LUOT_VIDEO_REVIEW = {
    "review_standard": {
        "ten": "⚡ Review Tiêu Chuẩn (Model 1 · Tự động tách cảnh + Thuyết minh nhanh · 10 lượt/video)",
        "so_luot": 10,
        "engine_ticket": "local_ocr_gpu",
    },
    "review_pro_character": {
        "ten": "🧠 Review Pro — Nhận Diện Sâu Nhân Vật & DeepSeek Ngữ Cảnh (Model 2 · 15 lượt/video)",
        "so_luot": 15,
        "engine_ticket": "local_hybrid_pro",
    },
    "review_ultra_cloud": {
        "ten": "✨ Review Ultra Cloud — Đa Phương Thức Gemini & DeepSeek Biên Kịch Sâu (Model 3 · 20 lượt/video)",
        "so_luot": 20,
        "engine_ticket": "llm_context",
    },
}


def xac_thuc_va_tru_luot_video_cloud(
    server_url: str,
    token: str,
    *,
    ma_goi: str = "review_standard",
    ma_dinh_danh_video: str = "",
) -> dict[str, Any]:
    """
    Xác thực tài khoản và khấu trừ số lượt tạo Video Review (`10` hoặc `15` lượt)
    trực tiếp trên Ví tài khoản Cloud (`https://translation-api.vibe1.tinhgon.xyz`)
    mà KHÔNG làm ảnh hưởng tới hệ thống Dịch Truyện.
    """
    base = (server_url or "https://translation-api.vibe1.tinhgon.xyz").strip().rstrip("/")
    tok = (token or "").strip()
    if not tok:
        raise RuntimeError(
            "Vui lòng đăng nhập hoặc dán Mã Phiên / API Key (tr_live_...) để xác thực lượt tạo Video Review."
        )

    goi = GOI_LUOT_VIDEO_REVIEW.get(ma_goi) or GOI_LUOT_VIDEO_REVIEW["review_standard"]
    tong_luot_can = int(goi["so_luot"])

    headers = {
        "Content-Type": "application/json",
        "User-Agent": "MangaVideoReviewStudio/1.0",
    }
    if tok.startswith("tr_live_"):
        headers["X-API-Key"] = tok
    else:
        headers["Authorization"] = f"Bearer {tok}"

    hm_req = urllib.request.Request(f"{base}/api/v1/han-muc", headers=headers, method="GET")
    try:
        with urllib.request.urlopen(hm_req, timeout=15) as resp:
            hm_data = json.loads(resp.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Không xác thực được tài khoản trên máy chủ (HTTP {exc.code}).") from exc
    except Exception as exc:
        raise RuntimeError(f"Không kết nối được máy chủ xác thực hạn mức: {exc}") from exc

    con_lai = int(hm_data.get("con_lai") or 0)
    la_quan_tri = bool(hm_data.get("la_quan_tri"))
    cap_do = int(hm_data.get("cap_do") or 0)
    mua_them = int(hm_data.get("so_luot_mua_them") or 0)
    if not la_quan_tri and cap_do < 1 and mua_them < tong_luot_can:
        raise RuntimeError(
            "Tính năng Dựng Video Review Truyện Tự Động không hỗ trợ gói Free dùng thử.\n"
            "Vui lòng nâng cấp lên gói trả phí hàng tháng (Starter $2.99 / Lite $5.99 / Standard $9.99 / Pro Max $19.99) "
            "tại https://comic.io.vn/#bang-gia để sử dụng Video Review Studio!"
        )
    if not la_quan_tri and con_lai < tong_luot_can:
        raise RuntimeError(
            f"Số dư tài khoản còn {con_lai} lượt, không đủ {tong_luot_can} lượt cho gói '{goi['ten']}'. "
            "Vui lòng nạp thêm lượt trên https://comic.io.vn/#bang-gia!"
        )

    seed = ma_dinh_danh_video or hashlib.sha256(os.urandom(16)).hexdigest()
    tickets: list[dict[str, Any]] = []
    da_tru = 0
    buoc = 0
    while da_tru < tong_luot_can:
        con_thieu = tong_luot_can - da_tru
        eng = "local_hybrid_pro" if con_thieu >= 2 else "local_ocr_gpu"
        step_hash = hashlib.sha256(f"{seed}:video_step:{buoc}".encode("utf-8")).hexdigest()
        body = json.dumps({"page_hash": step_hash, "engine": eng}).encode("utf-8")
        req = urllib.request.Request(
            f"{base}/api/v1/developer/consume-local-page",
            data=body,
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            kq = json.loads(resp.read().decode("utf-8", errors="replace"))
        if not kq.get("ok"):
            raise RuntimeError("Máy chủ từ chối cấp vé thực thi tạo Video.")
        if kq.get("execution_ticket"):
            tickets.append(kq["execution_ticket"])
        da_tru += 2 if eng == "local_hybrid_pro" else 1
        buoc += 1

    return {
        "ok": True,
        "ma_goi": ma_goi,
        "so_luot_da_tru": da_tru,
        "con_lai_sau_tru": max(0, con_lai - da_tru),
        "tickets": tickets,
    }


def _nap_font_phu_de(co_chu: int = 28, van_ban: str = ""):
    if ImageFont is None:
        return None
    import re
    if van_ban and re.search(r"[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]", van_ban):
        for fp in ("C:/Windows/Fonts/msyhbd.ttc", "C:/Windows/Fonts/msjhbd.ttc", "C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/msyh.ttc"):
            if os.path.isfile(fp):
                try:
                    return ImageFont.truetype(fp, co_chu)
                except Exception:
                    continue
    if van_ban and re.search(r"[\u0e00-\u0e7f]", van_ban):
        for fp in ("C:/Windows/Fonts/leelawdb.ttf", "C:/Windows/Fonts/leelawui.ttf", "C:/Windows/Fonts/tahomabd.ttf"):
            if os.path.isfile(fp):
                try:
                    return ImageFont.truetype(fp, co_chu)
                except Exception:
                    continue
    ds_font = [
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/tahoma.ttf",
    ]
    for fp in ds_font:
        if os.path.isfile(fp):
            try:
                return ImageFont.truetype(fp, co_chu)
            except Exception:
                continue
    return ImageFont.load_default()


def ve_khung_hinh_pan_zoom_va_phu_de(
    panel_bytes: bytes,
    *,
    loi_thuyet_minh: str,
    nhan_vat: str = "",
    kich_thuoc_video: tuple[int, int] = (720, 1280),
    tien_do_canh: float = 0.5,
    kieu_chuyen_dong: str = "pan_down",
    chi_so_canh: int = 0,
    tong_so_canh: int = 0,
) -> bytes:
    """
    Dựng 1 khung hình Video Review chuyên nghiệp cho cả YouTube Ngang (16:9) và Shorts/TikTok Dọc (9:16):
    - Trên màn hình Ngang 16:9 (`vw > vh`):
      + Chế độ `dual_split`: Tự động tách trang dọc thành Nửa Trên (Trái) & Nửa Dưới (Phải) đặt song song lấp đầy 92% màn hình,
        chuyển viền sáng vàng từ Trái (`t < 0.5`) sang Phải (`t >= 0.5`).
      + Chế độ `pan_down` / `zoom_in`: Phóng rộng trang truyện chiếm 72%–76% chiều ngang màn hình (không bị bé lọt thỏm ở giữa)
        và trượt dọc mượt mà từ đầu trang xuống cuối trang theo `tien_do_canh`.
      + Phụ đề Điện Ảnh 2 dòng tự động lật trang theo tiến độ câu nói (`Multi-Page Dynamic Subtitles`), KHÔNG BAO GIỜ cắt cụt chữ!
    - Trên màn hình Dọc 9:16 (`vh >= vw`):
      + Hiển thị tràn viền 95% chiều ngang + đặt phụ đề trong Vùng An Toàn (Safe-Zone) của YouTube Shorts / TikTok.
    """
    if Image is None:
        return panel_bytes

    vw, vh = kich_thuoc_video
    la_man_ngang = vw > vh
    t = max(0.0, min(1.0, float(tien_do_canh)))

    with Image.open(io.BytesIO(panel_bytes)) as raw_im:
        src = raw_im.convert("RGB")

    bg = src.resize((vw, vh))
    if ImageFilter is not None:
        bg = bg.filter(ImageFilter.GaussianBlur(radius=20))
    overlay_dark = Image.new("RGB", (vw, vh), (10, 15, 28))
    canvas = Image.blend(bg, overlay_dark, alpha=0.58)
    draw = ImageDraw.Draw(canvas)

    if la_man_ngang:
        # Màn hình Ngang YouTube 16:9 (1280x720 hoặc 1920x1080)
        py_top = int(vh * 0.02)
        vung_hien_thi_h = int(vh * 0.82)

        if kieu_chuyen_dong == "dual_split" and src.height >= int(src.width * 1.15):
            # Bố cục Ghép Đôi 2 Khung Trái - Phải lấp đầy 92% màn hình ngang 16:9
            col_w = int(vw * 0.44)
            gap = int(vw * 0.025)
            h_split_top = int(src.height * 0.55)
            h_split_bot_start = int(src.height * 0.45)

            img_left = src.crop((0, 0, src.width, h_split_top))
            img_right = src.crop((0, h_split_bot_start, src.width, src.height))

            def _fit_panel_box(im_part, box_w: int, box_h: int, local_t: float):
                scale_w = box_w / max(1, im_part.width)
                nh = max(1, int(im_part.height * scale_w))
                resized = im_part.resize((box_w, nh))
                if nh > box_h:
                    oy = int((nh - box_h) * max(0.0, min(1.0, local_t)))
                    return resized.crop((0, oy, box_w, oy + box_h))
                return resized

            fg_left = _fit_panel_box(img_left, col_w, vung_hien_thi_h, min(1.0, t * 1.6))
            fg_right = _fit_panel_box(img_right, col_w, vung_hien_thi_h, max(0.0, (t - 0.35) * 1.5))

            if t < 0.5:
                dark_r = Image.new("RGB", fg_right.size, (12, 18, 32))
                fg_right = Image.blend(fg_right, dark_r, alpha=0.22)
            else:
                dark_l = Image.new("RGB", fg_left.size, (12, 18, 32))
                fg_left = Image.blend(fg_left, dark_l, alpha=0.22)

            total_w = fg_left.width + gap + fg_right.width
            x_left = (vw - total_w) // 2
            x_right = x_left + fg_left.width + gap
            y_left = py_top + max(0, (vung_hien_thi_h - fg_left.height) // 2)
            y_right = py_top + max(0, (vung_hien_thi_h - fg_right.height) // 2)

            canvas.paste(fg_left, (x_left, y_left))
            canvas.paste(fg_right, (x_right, y_right))

            border_l = (245, 158, 11) if t < 0.5 else (148, 163, 184)
            border_r = (245, 158, 11) if t >= 0.5 else (148, 163, 184)
            draw.rectangle([x_left - 2, y_left - 2, x_left + fg_left.width + 2, y_left + fg_left.height + 2], outline=border_l, width=3 if t < 0.5 else 1)
            draw.rectangle([x_right - 2, y_right - 2, x_right + fg_right.width + 2, y_right + fg_right.height + 2], outline=border_r, width=3 if t >= 0.5 else 1)
        else:
            # Bố cục Smart Wide Focus & Vertical Pan: Phóng rộng trang truyện chiếm 72%-76% chiều ngang màn hình 16:9
            zoom_factor = (1.0 + 0.07 * t) if kieu_chuyen_dong == "zoom_in" else 1.0
            vung_hien_thi_w = int(vw * 0.72 * zoom_factor)
            ty_le_w = vung_hien_thi_w / max(1, src.width)
            new_h = max(1, int(src.height * ty_le_w))
            fg_full = src.resize((vung_hien_thi_w, new_h))

            if new_h > vung_hien_thi_h:
                max_offset_y = new_h - vung_hien_thi_h
                oy = int(max_offset_y * t)
                fg = fg_full.crop((0, oy, vung_hien_thi_w, oy + vung_hien_thi_h))
            else:
                fg = fg_full

            if fg.width > int(vw * 0.78):
                cx = fg.width // 2
                cw = int(vw * 0.78)
                fg = fg.crop((cx - cw // 2, 0, cx + cw // 2, fg.height))

            px = (vw - fg.width) // 2
            py = py_top + max(0, (vung_hien_thi_h - fg.height) // 2)
            canvas.paste(fg, (px, py))
            draw.rectangle([px - 2, py - 2, px + fg.width + 2, py + fg.height + 2], outline=(226, 232, 240), width=2)
    else:
        # Màn hình Dọc 9:16 (YouTube Shorts / TikTok / Reels — Full-Bleed Vertical & Safe-Zone)
        vung_hien_thi_h = int(vh * 0.76)
        vung_hien_thi_w = int(vw * 0.95)
        ty_le_w = vung_hien_thi_w / max(1, src.width)
        new_h = max(1, int(src.height * ty_le_w))
        fg_full = src.resize((vung_hien_thi_w, new_h))
        if new_h > vung_hien_thi_h:
            max_offset_y = new_h - vung_hien_thi_h
            oy = int(max_offset_y * t)
            fg = fg_full.crop((0, oy, vung_hien_thi_w, oy + vung_hien_thi_h))
        else:
            scale = 1.0 + 0.08 * t
            fg = src.resize((min(vung_hien_thi_w, int(fg_full.width * scale)), min(vung_hien_thi_h, int(fg_full.height * scale))))
        px = (vw - fg.width) // 2
        py = int(vh * 0.045) + max(0, (vung_hien_thi_h - fg.height) // 2)
        canvas.paste(fg, (px, py))
        draw.rectangle([px - 1, py - 1, px + fg.width + 1, py + fg.height + 1], outline=(245, 158, 11), width=2)

    scale_ui = vw / 1280.0 if la_man_ngang else vw / 720.0
    font_sub = _nap_font_phu_de(co_chu=max(22, int((28 if la_man_ngang else 25) * scale_ui)), van_ban=loi_thuyet_minh)
    font_tag = _nap_font_phu_de(co_chu=max(16, int(19 * scale_ui)), van_ban=nhan_vat)

    if nhan_vat:
        # Không dùng emoji 🎭 để tránh lỗi ô vuông □ trên font Arial Windows
        nhan_txt = nhan_vat  # chữ thuần: Arial trên Windows không có glyph ◆/🎭 → sẽ hiện ô vuông □
        tag_w = min(vw - 36, int(36 + len(nhan_txt) * 11.5 * scale_ui))
        tag_h = int(38 * scale_ui)
        draw.rounded_rectangle([20, 14, 20 + tag_w, 14 + tag_h], radius=8, fill=(185, 28, 28), outline=(253, 224, 71), width=2)
        draw.text((32, 19), nhan_txt, fill=(255, 255, 255), font=font_tag)

    if chi_so_canh > 0 and tong_so_canh > 0:
        sc_txt = f"Cảnh {chi_so_canh}/{tong_so_canh}"
        sc_w = int(28 + len(sc_txt) * 10.5 * scale_ui)
        sc_h = int(34 * scale_ui)
        draw.rounded_rectangle([vw - sc_w - 20, 14, vw - 20, 14 + sc_h], radius=8, fill=(15, 23, 42), outline=(148, 163, 184), width=1)
        draw.text((vw - sc_w - 8, 19), sc_txt, fill=(226, 232, 240), font=font_tag)

    if loi_thuyet_minh:
        so_ky_tu_dong = 72 if la_man_ngang else 34
        so_dong_moi_trang = 2 if la_man_ngang else 3
        tat_ca_dong = textwrap.wrap(loi_thuyet_minh.strip(), width=so_ky_tu_dong) or [loi_thuyet_minh.strip()]
        cac_trang_phu_de = [
            tat_ca_dong[i : i + so_dong_moi_trang]
            for i in range(0, len(tat_ca_dong), so_dong_moi_trang)
        ]
        idx_trang_sub = min(len(cac_trang_phu_de) - 1, int(t * len(cac_trang_phu_de)))
        cac_dong = cac_trang_phu_de[idx_trang_sub]

        if la_man_ngang:
            sub_y_top = int(vh * 0.845)
            sub_y_bot = vh - 10
            sub_x_left = int(vw * 0.03)
            sub_x_right = int(vw * 0.97)
            line_step = int(34 * scale_ui)
        else:
            # Safe-Zone chuẩn Shorts / TikTok: đẩy lên khỏi đáy 6% để không bị thanh caption che
            sub_y_top = int(vh * 0.815)
            sub_y_bot = int(vh * 0.945)
            sub_x_left = 18
            sub_x_right = vw - 18
            line_step = int(33 * scale_ui)

        draw.rounded_rectangle(
            [sub_x_left, sub_y_top, sub_x_right, sub_y_bot],
            radius=10,
            fill=(11, 17, 32),
            outline=(245, 158, 11),
            width=2,
        )
        for idx_d, dong in enumerate(cac_dong):
            dy = sub_y_top + int(10 * scale_ui) + idx_d * line_step
            tx = sub_x_left + int(18 * scale_ui)
            for ox, oy in ((-2, -2), (2, -2), (-2, 2), (2, 2)):
                draw.text((tx + ox, dy + oy), dong, fill=(0, 0, 0), font=font_sub)
            draw.text((tx, dy), dong, fill=(253, 224, 71), font=font_sub)

        if len(cac_trang_phu_de) > 1:
            ind_txt = f"{idx_trang_sub + 1}/{len(cac_trang_phu_de)}"
            draw.text((sub_x_right - int(44 * scale_ui), sub_y_bot - int(26 * scale_ui)), ind_txt, fill=(148, 163, 184), font=font_tag)

    # Thanh tiến trình thời lượng cảnh ở sát đáy màn hình
    prog_w = max(4, int(vw * (chi_so_canh - 1 + t) / max(1, tong_so_canh))) if tong_so_canh > 0 else int(vw * t)
    draw.rectangle([0, vh - 4, prog_w, vh], fill=(249, 115, 22))

    buf = io.BytesIO()
    canvas.save(buf, format="JPEG", quality=91)
    return buf.getvalue()


def ghep_cac_file_wav_thanh_master(wav_paths: list[Path], out_master_wav: Path) -> Path:
    """
    Ghép nối tuần tự tất cả file âm thanh `.wav` (hoặc `.mp3`) của từng phân cảnh
    thành 1 track âm thanh tổng (`out_master_wav`) để ghép đồng bộ vào luồng Video MP4.
    """
    out_master_wav.parent.mkdir(parents=True, exist_ok=True)
    frames_all: list[bytes] = []
    mp3_chunks: list[bytes] = []
    params = None
    ff_exe = tim_ffmpeg_he_thong()
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    def _chuan_hoa_wav(wp: Path) -> Path:
        if not wp.is_file():
            return wp
        if wp.suffix.lower() == ".mp3" and ff_exe:
            conv_wav = wp.with_suffix(".wav")
            try:
                subprocess.run(
                    [ff_exe, "-y", "-i", str(wp), "-ar", "24000", "-ac", "1", "-c:a", "pcm_s16le", str(conv_wav)],
                    timeout=20,
                    check=True,
                    creationflags=flags,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                if conv_wav.is_file() and conv_wav.stat().st_size > 128:
                    return conv_wav
            except Exception:
                pass
        return wp

    from concurrent.futures import ThreadPoolExecutor

    with ThreadPoolExecutor(max_workers=6) as pool:
        resolved_paths = list(pool.map(_chuan_hoa_wav, wav_paths))

    for cur_p in resolved_paths:
        if not cur_p.is_file():
            continue
        if cur_p.suffix.lower() == ".mp3":
            mp3_chunks.append(cur_p.read_bytes())
            continue
        try:
            with wave.open(str(cur_p), "rb") as rf:
                if params is None:
                    params = rf.getparams()
                frames_all.append(rf.readframes(rf.getnframes()))
        except Exception:
            continue

    if mp3_chunks and not frames_all:
        out_mp3 = out_master_wav.with_suffix(".mp3")
        out_mp3.write_bytes(b"".join(mp3_chunks))
        return out_mp3

    with wave.open(str(out_master_wav), "wb") as wf:
        if params is not None:
            wf.setparams(params)
        else:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(24000)
        for chunk in frames_all:
            wf.writeframes(chunk)
    return out_master_wav


def pha_tron_nhac_nen_va_hieu_ung_chuyen_canh(
    master_wav_path: Path,
    scenes: list[dict[str, Any]],
    *,
    ma_nhac_nen: str = "tu_dong_theo_phong_cach",
    phong_cach_kich_ban: str = "kich_tinh",
) -> Path:
    """
    Trộn Nhạc nền không bản quyền (Procedural Harmonic BGM ở mức -18dB) + Hiệu ứng âm thanh chuyển cảnh (`Whoosh`)
    kèm cơ chế Auto-Ducking (tự động hạ nhỏ nhạc nền khi có tiếng người đọc để giọng thuyết minh luôn rõ 100%).
    """
    if not master_wav_path.is_file() or master_wav_path.suffix.lower() != ".wav" or ma_nhac_nen == "tat_nhac_nen":
        return master_wav_path

    kieu_bgm = ma_nhac_nen
    if kieu_bgm == "tu_dong_theo_phong_cach":
        kieu_bgm = {
            "kich_tinh": "bgm_kich_tinh",
            "hai_huoc": "bgm_hai_huoc",
            "tu_tien": "bgm_tu_tien",
            "ngon_tinh": "bgm_cam_xuc",
        }.get(phong_cach_kich_ban, "bgm_kich_tinh")

    hop_am_theo_kieu = {
        "bgm_kich_tinh": [(110.0, 130.81, 164.81), (87.31, 110.0, 130.81), (98.0, 123.47, 146.83), (82.41, 103.83, 123.47)],
        "bgm_hai_huoc": [(261.63, 329.63, 392.0), (293.66, 369.99, 440.0), (329.63, 392.0, 493.88), (261.63, 349.23, 440.0)],
        "bgm_tu_tien": [(146.83, 174.61, 220.0), (130.81, 164.81, 196.0), (110.0, 146.83, 174.61), (130.81, 174.61, 220.0)],
        "bgm_cam_xuc": [(130.81, 164.81, 196.0), (110.0, 130.81, 164.81), (87.31, 110.0, 130.81), (98.0, 123.47, 146.83)],
    }
    ds_hop_am = hop_am_theo_kieu.get(kieu_bgm, hop_am_theo_kieu["bgm_kich_tinh"])

    try:
        with wave.open(str(master_wav_path), "rb") as rf:
            n_channels = rf.getnchannels()
            sampwidth = rf.getsampwidth()
            framerate = rf.getframerate()
            n_frames = rf.getnframes()
            raw_bytes = rf.readframes(n_frames)

        if sampwidth != 2 or n_channels != 1 or n_frames <= 0:
            return master_wav_path

        samples = array.array("h")
        samples.frombytes(raw_bytes)
        total_samples = len(samples)

        # Tính danh sách mốc mẫu (sample index) bắt đầu mỗi phân cảnh mới để chèn tiếng Whoosh chuyển cảnh
        moc_chuyen_canh: list[int] = []
        t_acc = 0.0
        for idx_s, sc in enumerate(scenes):
            if idx_s > 0:
                idx_sample = int(t_acc * framerate)
                if 0 < idx_sample < total_samples - int(0.25 * framerate):
                    moc_chuyen_canh.append(idx_sample)
            t_acc += float(sc.get("thoi_luong_giay") or 3.0)

        # Chiều dài mỗi hợp âm ~ 2.0 giây, tính sẵn 1 chu kỳ 8 giây để trộn cực nhanh (< 50ms)
        chord_len = max(1, int(framerate * 2.0))
        cycle_len = chord_len * 4
        bgm_cycle = array.array("h", [0] * cycle_len)
        two_pi = 2.0 * math.pi
        beat_len = max(1, int(framerate * 0.5))

        for i in range(cycle_len):
            chord = ds_hop_am[(i // chord_len) % 4]
            t = i / float(framerate)
            pos_in_beat = (i % beat_len) / float(beat_len)
            env_beat = 0.65 + 0.35 * math.exp(-3.5 * pos_in_beat)
            val = (
                0.48 * math.sin(two_pi * chord[0] * t)
                + 0.32 * math.sin(two_pi * chord[1] * t)
                + 0.20 * math.sin(two_pi * chord[2] * t)
            )
            bgm_cycle[i] = int(950.0 * env_beat * val)

        # Trộn BGM (Auto-Ducking khi có tiếng đọc lớn)
        for i in range(total_samples):
            v = samples[i]
            b = bgm_cycle[i % cycle_len]
            if abs(v) > 3500:
                b = (b * 55) // 100
            mixed = v + b
            if mixed > 32760:
                mixed = 32760
            elif mixed < -32760:
                mixed = -32760
            samples[i] = mixed

        # Chèn hiệu ứng âm thanh chuyển cảnh Whoosh nhẹ (0.18s) ở đầu mỗi khung tranh mới
        whoosh_samples = int(0.18 * framerate)
        for start_i in moc_chuyen_canh:
            for k in range(whoosh_samples):
                idx = start_i + k
                if idx >= total_samples:
                    break
                u = k / float(whoosh_samples)
                env_w = math.sin(math.pi * u)
                freq_w = 380.0 - 240.0 * u
                w_val = int(1350.0 * env_w * math.sin(two_pi * freq_w * (k / float(framerate))))
                mixed = samples[idx] + w_val
                if mixed > 32760:
                    mixed = 32760
                elif mixed < -32760:
                    mixed = -32760
                samples[idx] = mixed

        with wave.open(str(master_wav_path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(framerate)
            wf.writeframes(samples.tobytes())
    except Exception:
        pass
    return master_wav_path


def _tim_ffmpeg_exe() -> str | None:
    return tim_ffmpeg_he_thong()


def _tao_container_mp4_hop_le_du_phong(frames_jpeg: list[bytes], out_mp4: Path) -> None:
    """
    Đóng gói container ISO-BMFF MP4 chuẩn (`ftypisom` + `mdat` chứa chuỗi khung hình đã dựng)
    trong trường hợp máy khách chưa cài đặt `ffmpeg`, đảm bảo luôn xuất ra file `.mp4` hợp lệ.
    """
    ftyp = b"\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2mp41"
    payload = b"".join(frames_jpeg)
    mdat_len = 8 + len(payload)
    mdat_hdr = mdat_len.to_bytes(4, "big") + b"mdat"
    out_mp4.parent.mkdir(parents=True, exist_ok=True)
    out_mp4.write_bytes(ftyp + mdat_hdr + payload)


def xuat_video_review_mp4(
    panels_bytes: list[bytes],
    kich_ban: dict[str, Any],
    out_mp4_path: Path,
    *,
    ma_dinh_dang: str = "tiktok_9_16",
    ma_giong: str = "chi_google_review_chuan",
    ma_nhac_nen: str = "tu_dong_theo_phong_cach",
    toc_do_doc: float = 1.15,
    file_giong_mau_clone: str | Path | None = None,
    elevenlabs_api_key: str | None = None,
    elevenlabs_voice_id: str | None = None,
    che_do_nhanh_offline: bool = False,
) -> dict[str, Any]:
    """
    Quy trình khép kín dựng Video Review Truyện `.mp4` + âm thanh tổng `.wav` + phụ đề `.srt` + `storyboard.json`:
    1. Tổng hợp giọng đọc thuyết minh cho từng phân cảnh (`scenes`).
    2. Dựng các khung hình chuyển động Pan & Zoom kèm phụ đề chữ vàng.
    3. Ghép cả hình lẫn tiếng nói thành file `.mp4` hoàn chỉnh.
    """
    scenes = list(kich_ban.get("scenes") or [])
    if not panels_bytes or not scenes:
        raise ValueError("Cần có đủ khung tranh và kịch bản để xuất Video Review.")

    dinh_dang = DINH_DANG_VIDEO.get(ma_dinh_dang) or DINH_DANG_VIDEO["tiktok_9_16"]
    kich_thuoc = dinh_dang["kich_thuoc"]

    out_mp4_path = Path(out_mp4_path)
    out_dir = out_mp4_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)
    work_dir = out_dir / "_temp_studio_build"
    work_dir.mkdir(parents=True, exist_ok=True)

    from concurrent.futures import ThreadPoolExecutor

    tong_thoi_luong = 0.0
    frames_jpeg: list[bytes] = []
    concat_lines: list[str] = []
    wav_files: list[Path] = []
    so_canh_tong = len(scenes)
    cac_moc_tien_do = (0.12, 0.38, 0.64, 0.88)
    so_buoc_canh = len(cac_moc_tien_do)

    def _xu_ly_mot_canh(idx_and_sc: tuple[int, dict[str, Any]]) -> tuple[int, dict[str, Any], list[bytes]]:
        idx, sc = idx_and_sc
        p_bytes = panels_bytes[min(idx, len(panels_bytes) - 1)]
        loi = str(sc.get("loi_thuyet_minh") or "").strip()
        nhan_vat = str(sc.get("nhan_vat") or "").strip()
        kieu_cam = str(sc.get("hieu_ung_camera") or "pan_down")

        tts_info = tong_hop_giong_doc_phan_canh(
            loi,
            work_dir,
            scene_index=idx + 1,
            ma_giong=ma_giong,
            toc_do=toc_do_doc,
            cam_xuc=str(sc.get("cam_xuc") or kich_ban.get("phong_cach") or "kich_tinh"),
            vai_tro_nhan_vat=str(sc.get("vai_tro") or ""),
            ten_nhan_vat=nhan_vat,
            file_giong_mau_clone=file_giong_mau_clone,
            elevenlabs_api_key=elevenlabs_api_key,
            elevenlabs_voice_id=elevenlabs_voice_id,
            che_do_nhanh_offline=che_do_nhanh_offline,
        )
        sc_frames: list[bytes] = []
        for step_idx, t_ratio in enumerate(cac_moc_tien_do):
            frame_b = ve_khung_hinh_pan_zoom_va_phu_de(
                p_bytes,
                loi_thuyet_minh=loi,
                nhan_vat=nhan_vat,
                kich_thuoc_video=kich_thuoc,
                tien_do_canh=t_ratio,
                kieu_chuyen_dong=kieu_cam,
                chi_so_canh=idx + 1,
                tong_so_canh=so_canh_tong,
            )
            sc_frames.append(frame_b)
            frame_file = work_dir / f"frame_{idx + 1:03d}_{step_idx}.jpg"
            frame_file.write_bytes(frame_b)
        return idx, tts_info, sc_frames

    with ThreadPoolExecutor(max_workers=6) as pool:
        results_sc = list(pool.map(_xu_ly_mot_canh, enumerate(scenes)))

    for idx, tts_info, sc_frames in sorted(results_sc, key=lambda x: x[0]):
        sc = scenes[idx]
        thoi_luong = float(tts_info["thoi_luong_giay"])
        sc["thoi_luong_giay"] = thoi_luong
        sc["audio_path"] = tts_info["audio_path"]
        wav_files.append(Path(tts_info["audio_path"]))
        tong_thoi_luong += thoi_luong
        frames_jpeg.extend(sc_frames)
        dur_step = round(max(0.25, thoi_luong / float(so_buoc_canh)), 3)
        for step_idx in range(so_buoc_canh):
            frame_file = work_dir / f"frame_{idx + 1:03d}_{step_idx}.jpg"
            safe_fp = str(frame_file.resolve()).replace("\\", "/")
            concat_lines.append(f"file '{safe_fp}'\nduration {dur_step}")
            last_safe_fp = safe_fp

    if concat_lines and locals().get("last_safe_fp"):
        # Quy chuẩn FFmpeg concat demuxer: lặp lại dòng file cuối cùng (không kèm duration) để giữ trọn vẹn khung hình cuối
        concat_lines.append(f"file '{last_safe_fp}'")

    # Dọn dẹp file _voice.mp3 / _voice.wav cũ ngoài thư mục chính để tránh người dùng mở nhầm file âm thanh thay vì file .mp4
    for old_ext in (".mp3", ".wav"):
        old_voice = out_mp4_path.with_name(f"{out_mp4_path.stem}_voice{old_ext}")
        if old_voice.is_file():
            try:
                old_voice.unlink()
            except Exception:
                pass

    # Ghép track âm thanh thuyết minh tổng (.wav) trong thư mục tạm và trộn nhạc nền + hiệu ứng chuyển cảnh Whoosh
    out_audio_master = ghep_cac_file_wav_thanh_master(
        wav_files, work_dir / f"{out_mp4_path.stem}_voice.wav"
    )
    # Đồng bộ lại chính xác thời lượng từng phân cảnh theo file .wav thực tế sau chuyển đổi để khớp 100% hình và tiếng
    concat_lines = []
    last_safe_fp = ""
    tong_thoi_luong = 0.0
    for idx, sc in enumerate(scenes):
        cand_wav = work_dir / f"scene_{idx + 1:03d}.wav"
        if cand_wav.is_file():
            try:
                with wave.open(str(cand_wav), "rb") as rf:
                    sc["thoi_luong_giay"] = round(max(0.8, rf.getnframes() / float(rf.getframerate() or 24000)), 3)
            except Exception:
                pass
        dur_sc = float(sc.get("thoi_luong_giay") or 3.0)
        tong_thoi_luong += dur_sc
        dur_step = round(max(0.25, dur_sc / float(so_buoc_canh)), 3)
        for step_idx in range(so_buoc_canh):
            frame_file = work_dir / f"frame_{idx + 1:03d}_{step_idx}.jpg"
            safe_fp = str(frame_file.resolve()).replace("\\", "/")
            concat_lines.append(f"file '{safe_fp}'\nduration {dur_step}")
            last_safe_fp = safe_fp
    if concat_lines and last_safe_fp:
        concat_lines.append(f"file '{last_safe_fp}'")

    out_audio_master = pha_tron_nhac_nen_va_hieu_ung_chuyen_canh(
        out_audio_master,
        scenes,
        ma_nhac_nen=ma_nhac_nen,
        phong_cach_kich_ban=str(kich_ban.get("phong_cach") or "kich_tinh"),
    )

    out_srt_path = out_mp4_path.with_suffix(".srt")
    xuat_phu_de_srt(scenes, out_srt_path)

    out_json_path = out_mp4_path.with_name(f"{out_mp4_path.stem}_storyboard.json")
    kich_ban_luu = dict(kich_ban)
    kich_ban_luu["tong_thoi_luong_giay"] = round(tong_thoi_luong, 2)
    kich_ban_luu["dinh_dang_video"] = ma_dinh_dang
    kich_ban_luu["ma_giong"] = ma_giong
    kich_ban_luu["master_audio_path"] = str(out_audio_master)
    out_json_path.write_text(json.dumps(kich_ban_luu, ensure_ascii=False, indent=2), encoding="utf-8")

    ffmpeg_exe = _tim_ffmpeg_exe()
    da_xuat_ffmpeg = False
    if ffmpeg_exe and concat_lines:
        try:
            concat_file = work_dir / "frames_concat.txt"
            concat_file.write_text("\n".join(concat_lines) + "\n", encoding="utf-8")
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.run(
                [
                    ffmpeg_exe,
                    "-y",
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    str(concat_file),
                    "-i",
                    str(out_audio_master),
                    "-vf",
                    "fps=24,scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p",
                    "-c:v",
                    "libx264",
                    "-preset",
                    "veryfast",
                    "-crf",
                    "21",
                    "-pix_fmt",
                    "yuv420p",
                    "-movflags",
                    "+faststart",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "160k",
                    "-shortest",
                    str(out_mp4_path),
                ],
                timeout=300,
                check=True,
                creationflags=flags,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            da_xuat_ffmpeg = out_mp4_path.is_file() and out_mp4_path.stat().st_size > 1024
        except Exception:
            da_xuat_ffmpeg = False

    if not da_xuat_ffmpeg:
        _tao_container_mp4_hop_le_du_phong(frames_jpeg, out_mp4_path)

    # Giai đoạn 4: Nếu chọn 'dual_youtube_va_shorts', dùng ngay cùng bộ âm thanh tổng (`out_audio_master`)
    # để render thêm bản Dọc 9:16 (TikTok / YouTube Shorts) mà KHÔNG cần chạy lại TTS!
    shorts_9_16_path_str = ""
    if ma_dinh_dang == "dual_youtube_va_shorts":
        stem_goc = re.sub(r"(_youtube_16_9|_dual_youtube_va_shorts|_tiktok_9_16)$", "", out_mp4_path.stem)
        shorts_mp4 = out_mp4_path.with_name(f"{stem_goc}_tiktok_9_16.mp4")
        kich_thuoc_doc = (720, 1280)

        def _ve_canh_doc_9_16(idx_and_sc: tuple[int, dict[str, Any]]) -> tuple[int, list[bytes]]:
            idx, sc = idx_and_sc
            p_bytes = panels_bytes[min(idx, len(panels_bytes) - 1)]
            loi = str(sc.get("loi_thuyet_minh") or "").strip()
            nhan_vat = str(sc.get("nhan_vat") or "").strip()
            kieu_cam = str(sc.get("hieu_ung_camera") or "pan_down")
            sc_f: list[bytes] = []
            for step_idx, t_ratio in enumerate(cac_moc_tien_do):
                fb = ve_khung_hinh_pan_zoom_va_phu_de(
                    p_bytes,
                    loi_thuyet_minh=loi,
                    nhan_vat=nhan_vat,
                    kich_thuoc_video=kich_thuoc_doc,
                    tien_do_canh=t_ratio,
                    kieu_chuyen_dong=kieu_cam,
                    chi_so_canh=idx + 1,
                    tong_so_canh=so_canh_tong,
                )
                sc_f.append(fb)
                (work_dir / f"vframe_{idx + 1:03d}_{step_idx}.jpg").write_bytes(fb)
            return idx, sc_f

        with ThreadPoolExecutor(max_workers=6) as pool:
            res_doc = list(pool.map(_ve_canh_doc_9_16, enumerate(scenes)))

        frames_doc: list[bytes] = []
        concat_doc: list[str] = []
        last_vfp = ""
        for idx, sc_f in sorted(res_doc, key=lambda x: x[0]):
            frames_doc.extend(sc_f)
            dur_sc = float(scenes[idx].get("thoi_luong_giay") or 3.0)
            dur_step = round(max(0.25, dur_sc / float(so_buoc_canh)), 3)
            for step_idx in range(so_buoc_canh):
                vfile = work_dir / f"vframe_{idx + 1:03d}_{step_idx}.jpg"
                safe_vfp = str(vfile.resolve()).replace("\\", "/")
                concat_doc.append(f"file '{safe_vfp}'\nduration {dur_step}")
                last_vfp = safe_vfp
        if concat_doc and last_vfp:
            concat_doc.append(f"file '{last_vfp}'")

        da_xuat_doc = False
        if ffmpeg_exe and concat_doc:
            try:
                concat_vfile = work_dir / "vframes_concat.txt"
                concat_vfile.write_text("\n".join(concat_doc) + "\n", encoding="utf-8")
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                subprocess.run(
                    [
                        ffmpeg_exe, "-y", "-f", "concat", "-safe", "0",
                        "-i", str(concat_vfile), "-i", str(out_audio_master),
                        "-vf", "fps=24,scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p",
                        "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
                        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
                        "-c:a", "aac", "-b:a", "160k", "-shortest", str(shorts_mp4),
                    ],
                    timeout=300,
                    check=True,
                    creationflags=flags,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                da_xuat_doc = shorts_mp4.is_file() and shorts_mp4.stat().st_size > 1024
            except Exception:
                da_xuat_doc = False
        if not da_xuat_doc:
            _tao_container_mp4_hop_le_du_phong(frames_doc, shorts_mp4)
        shorts_9_16_path_str = str(shorts_mp4)

    return {
        "ok": True,
        "video_path": str(out_mp4_path),
        "shorts_9_16_video_path": shorts_9_16_path_str,
        "audio_master_path": str(out_audio_master),
        "srt_path": str(out_srt_path),
        "storyboard_json_path": str(out_json_path),
        "so_phan_canh": len(scenes),
        "tong_thoi_luong_giay": round(tong_thoi_luong, 2),
        "kich_thuoc_video": kich_thuoc,
    }
